#!/usr/bin/env node
// Deterministic, refutation-oriented sweep for the OVMG closed-loop model.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  basinSeparationDiagnostic,
  endpointConcentrationDiagnostic,
  findMeanFieldFixedPoints,
  simulateClosedLoop,
  tailMeanTheta,
} from '../js/closed-loop-sim.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUTPUT_PATH = path.resolve(HERE, '../results/closed-loop-sweep.json');
const STEPS = 320;
const REPLICATES = 36;
const SEED_BASE = 2026082200;

const BASE = Object.freeze({
  speakerCount: 80,
  initialInclusionRate: 0.5,
  initialEvidenceStrength: 40,
  priorA: 1,
  priorB: 1,
  targetUtility: 0,
  competitorUtility: 0,
  outsideUtility: -4,
  opportunitiesPerStep: 12,
  observationProbability: 0.6,
  deltaM: 0.96,
  inclusionUpdateRate: 0.08,
  adoptionThreshold: 0.5,
  adoptionSlope: 8,
  majorityRepairProbability: 0,
});

function runCell(label, overrides, options = {}) {
  const {
    replicateCount = REPLICATES,
    initialRates = [0.1, 0.5, 0.9],
  } = options;
  const params = { ...BASE, ...overrides };
  const tailTheta = [];
  const tailByInitial = new Map(initialRates.map((rate) => [rate, []]));
  const finalRows = [];
  for (let replicate = 0; replicate < replicateCount; replicate += 1) {
    const initialInclusionRate = initialRates[replicate % initialRates.length];
    const run = simulateClosedLoop(
      { ...params, initialInclusionRate, initialEvidenceRate: initialInclusionRate },
      STEPS,
      SEED_BASE + replicate,
    );
    const tail = tailMeanTheta(run);
    tailTheta.push(tail);
    tailByInitial.get(initialInclusionRate).push(tail);
    finalRows.push(run.rows.at(-1));
  }
  const mean = (values) => values.reduce((total, value) => total + value, 0) / values.length;
  return {
    label,
    params: {
      ...params,
      opportunitiesPerStep: typeof params.opportunitiesPerStep === 'function'
        ? '[function]'
        : params.opportunitiesPerStep,
    },
    initialRates,
    endpointDiagnostic: endpointConcentrationDiagnostic(tailTheta),
    basinDiagnostic: initialRates.length >= 2
      ? basinSeparationDiagnostic(
        tailByInitial.get(initialRates[0]),
        tailByInitial.get(initialRates.at(-1)),
      )
      : null,
    middleInitialDiagnostic: initialRates.length >= 3
      ? endpointConcentrationDiagnostic(tailByInitial.get(initialRates[1]))
      : null,
    meanFinalEvidenceMean: mean(finalRows.map((row) => row.evidenceMean)),
    meanFinalConcentration: mean(finalRows.map((row) => row.concentrationMean)),
    meanFinalEvidenceMeanVariance: mean(finalRows.map((row) => row.evidenceMeanVariance)),
    meanFinalApproximationThirdMomentError: mean(finalRows.map(
      (row) => row.approximationThirdMomentErrorMean,
    )),
    maximumFinalApproximationThirdMomentError: Math.max(...finalRows.map(
      (row) => row.approximationThirdMomentErrorMax,
    )),
    tailTheta,
  };
}

function runMeanFieldDiagnostic(label, overrides) {
  const params = { ...BASE, ...overrides };
  return {
    label,
    params,
    fixedPoints: findMeanFieldFixedPoints(params, {
      gridSize: 120,
      tolerance: 1e-9,
    }),
    scope: 'Expected-power deterministic closure; stability uses the full (theta,a,b) Jacobian.',
  };
}

function runBasinReturn() {
  const shockStep = 160;
  const arms = [
    { label: 'low', initialRate: 0.1, shockRate: 0.48, endpoint: 'low' },
    { label: 'high', initialRate: 0.9, shockRate: 0.52, endpoint: 'high' },
  ];
  const armResults = arms.map((arm, armIndex) => {
    const tails = [];
    for (let replicate = 0; replicate < 24; replicate += 1) {
      const run = simulateClosedLoop({
        ...BASE,
        initialInclusionRate: arm.initialRate,
        initialEvidenceRate: arm.initialRate,
        adoptionFamily: 'posteriorThreshold',
        shocks: [{ step: shockStep, inclusionRate: arm.shockRate }],
      }, STEPS, SEED_BASE + 1000 + (armIndex * 100) + replicate);
      tails.push(tailMeanTheta(run));
    }
    const returnedFraction = tails.filter((theta) => (
      arm.endpoint === 'low' ? theta <= 0.2 : theta >= 0.8
    )).length / tails.length;
    return { ...arm, replicateCount: tails.length, returnedFraction, tails };
  });
  return {
    label: 'return after within-separatrix inclusion perturbation',
    shockStep,
    parameters: {
      adoptionFamily: 'posteriorThreshold',
      note: 'The shock changes inclusion states but deliberately leaves evidence histories intact.',
    },
    arms: armResults,
    bothReturn: armResults.every((arm) => arm.returnedFraction >= 0.8),
    scope: 'Finite-horizon return diagnostic for the coupled state, not a stationary-distribution result.',
  };
}

function runEvidenceStateReturn() {
  const shockStep = 160;
  const arms = [
    { label: 'low', initialRate: 0.1, shockEvidenceRate: 0.3, endpoint: 'low' },
    { label: 'high', initialRate: 0.9, shockEvidenceRate: 0.7, endpoint: 'high' },
  ];
  const armResults = arms.map((arm, armIndex) => {
    const tails = [];
    for (let replicate = 0; replicate < 24; replicate += 1) {
      const run = simulateClosedLoop({
        ...BASE,
        initialInclusionRate: arm.initialRate,
        initialEvidenceRate: arm.initialRate,
        adoptionFamily: 'posteriorThreshold',
        evidenceShocks: [{
          step: shockStep,
          evidenceRate: arm.shockEvidenceRate,
          evidenceStrength: 40,
        }],
      }, STEPS, SEED_BASE + 1400 + (armIndex * 100) + replicate);
      tails.push(tailMeanTheta(run));
    }
    const returnedFraction = tails.filter((theta) => (
      arm.endpoint === 'low' ? theta <= 0.2 : theta >= 0.8
    )).length / tails.length;
    return { ...arm, replicateCount: tails.length, returnedFraction, tails };
  });
  return {
    label: 'return after a moderate evidence-state perturbation',
    shockStep,
    parameters: {
      adoptionFamily: 'posteriorThreshold',
      evidenceStrength: 40,
      note: 'The shock resets the slow evidence state toward the separatrix without directly changing inclusion.',
    },
    arms: armResults,
    bothReturn: armResults.every((arm) => arm.returnedFraction >= 0.8),
    scope: 'Finite-horizon local return after a declared full-state perturbation; larger shocks can cross the basin boundary.',
  };
}

function firstStepAtOrAfter(rows, startStep, predicate) {
  const row = rows.find((item) => item.step >= startStep && predicate(item));
  return row ? row.step : null;
}

function runMoribundDispersion() {
  const opportunityDropStep = 160;
  const progressFractions = [0.25, 0.5];
  const runs = [];
  for (let replicate = 0; replicate < REPLICATES; replicate += 1) {
    const run = simulateClosedLoop({
      ...BASE,
      initialInclusionRate: 0.9,
      initialEvidenceRate: 0.9,
      priorMeanSpread: 0.25,
      adoptionFamily: 'posteriorThreshold',
      opportunitiesPerStep: (step) => step <= opportunityDropStep ? 30 : 0,
    }, STEPS, SEED_BASE + replicate);
    const reference = run.rows[opportunityDropStep];
    const final = run.rows.at(-1);
    const totalMeanChange = Math.abs(final.evidenceMean - reference.evidenceMean);
    const totalVarianceChange = Math.abs(final.evidenceMeanVariance - reference.evidenceMeanVariance);
    const onsets = Object.fromEntries(progressFractions.map((fraction) => {
      const meanStep = firstStepAtOrAfter(
        run.rows,
        opportunityDropStep + 1,
        (row) => totalMeanChange > 0 &&
          Math.abs(row.evidenceMean - reference.evidenceMean) / totalMeanChange >= fraction,
      );
      const varianceStep = firstStepAtOrAfter(
        run.rows,
        opportunityDropStep + 1,
        (row) => totalVarianceChange > 0 &&
          Math.abs(row.evidenceMeanVariance - reference.evidenceMeanVariance) /
            totalVarianceChange >= fraction,
      );
      return [fraction, {
        meanStep,
        varianceStep,
        varianceLeads: meanStep !== null && varianceStep !== null && varianceStep < meanStep,
      }];
    }));
    runs.push({
      onsets,
      referenceEvidenceMean: reference.evidenceMean,
      referenceVariance: reference.evidenceMeanVariance,
      preDropEvidenceMean: run.rows[opportunityDropStep - 40].evidenceMean,
      preDropVariance: run.rows[opportunityDropStep - 40].evidenceMeanVariance,
      finalEvidenceMean: final.evidenceMean,
      finalVariance: final.evidenceMeanVariance,
      finalTheta: final.theta,
    });
  }
  const mean = (values) => values.reduce((total, value) => total + value, 0) / values.length;
  const ordering = Object.fromEntries(progressFractions.map((fraction) => {
    const detected = runs.filter((run) => (
      run.onsets[fraction].meanStep !== null && run.onsets[fraction].varianceStep !== null
    ));
    return [fraction, {
      detected: detected.length,
      varianceLeadsFraction: detected.length === 0
        ? null
        : detected.filter((run) => run.onsets[fraction].varianceLeads).length /
          detected.length,
      meanMeanStep: detected.length === 0
        ? null
        : mean(detected.map((run) => run.onsets[fraction].meanStep)),
      meanVarianceStep: detected.length === 0
        ? null
        : mean(detected.map((run) => run.onsets[fraction].varianceStep)),
    }];
  }));
  return {
    label: 'opportunity drop with heterogeneous priors',
    parameters: {
      opportunityDropStep,
      opportunitiesBefore: 30,
      opportunitiesAfter: 0,
      priorMeanSpread: 0.25,
      progressFractions,
    },
    replicateCount: runs.length,
    normalizedTrajectoryOrdering: ordering,
    meanPreDropDrift: mean(runs.map((run) => (
      Math.abs(run.referenceEvidenceMean - run.preDropEvidenceMean)
    ))),
    meanPreDropVarianceDrift: mean(runs.map((run) => (
      Math.abs(run.referenceVariance - run.preDropVariance)
    ))),
    meanReferenceVariance: mean(runs.map((run) => run.referenceVariance)),
    meanFinalVariance: mean(runs.map((run) => run.finalVariance)),
    meanReferenceEvidenceMean: mean(runs.map((run) => run.referenceEvidenceMean)),
    meanFinalEvidenceMean: mean(runs.map((run) => run.finalEvidenceMean)),
    meanFinalTheta: mean(runs.map((run) => run.finalTheta)),
    runs,
    scope: 'Tests a precursor mechanism in speaker evidence means, not judgment ratings.',
  };
}

const responseFamilies = ['mean', 'logisticMean', 'posteriorThreshold'].map(
  (adoptionFamily) => runCell(adoptionFamily, { adoptionFamily }),
);

const outsideOption = [-4, 0, 5].map((outsideUtility) => (
  runCell(`outsideUtility=${outsideUtility}`, {
    adoptionFamily: 'posteriorThreshold',
    outsideUtility,
  })
));

const memoryOpportunity = [];
for (const deltaM of [0.9, 0.96, 1]) {
  for (const opportunitiesPerStep of [2, 12, 30]) {
    memoryOpportunity.push(runCell(
      `deltaM=${deltaM};opportunities=${opportunitiesPerStep}`,
      { adoptionFamily: 'posteriorThreshold', deltaM, opportunitiesPerStep },
      { replicateCount: 24 },
    ));
  }
}

const omissionAttributionSensitivity = [0.25, 0.5, 0.75, 1].map((omissionAttribution) => (
  runCell(`omissionAttribution=${omissionAttribution}`, {
    adoptionFamily: 'posteriorThreshold',
    omissionAttribution,
  })
));

const adoptionNonlinearity = [2, 4, 8, 16, 32].map((adoptionSlope) => (
  runCell(`logisticSlope=${adoptionSlope}`, {
    adoptionFamily: 'logisticMean',
    adoptionSlope,
  })
));

const repairIntervention = [0, 0.25].map((majorityRepairProbability) => (
  runCell(`repairProbability=${majorityRepairProbability}`, {
    adoptionFamily: 'posteriorThreshold',
    majorityRepairProbability,
    shocks: [{ step: 160, inclusionRate: 0.52 }],
  }, { replicateCount: 24, initialRates: [0.85] })
));
const basinReturn = runBasinReturn();
const evidenceStateReturn = runEvidenceStateReturn();
const moribundDispersion = runMoribundDispersion();
const meanFieldDiagnostics = [
  ...['mean', 'logisticMean', 'posteriorThreshold'].map((adoptionFamily) => (
    runMeanFieldDiagnostic(adoptionFamily, { adoptionFamily })
  )),
  ...[2, 4, 8, 16, 32].map((adoptionSlope) => runMeanFieldDiagnostic(
    `logisticSlope=${adoptionSlope}`,
    { adoptionFamily: 'logisticMean', adoptionSlope },
  )),
];

const outsideDominated = outsideOption.find((cell) => cell.params.outsideUtility === 5);
const repairAbsent = repairIntervention.find(
  (cell) => cell.params.majorityRepairProbability === 0,
);
const repairPresent = repairIntervention.find(
  (cell) => cell.params.majorityRepairProbability === 0.25,
);
const nonlinearSeparated = adoptionNonlinearity.filter(
  (cell) => cell.basinDiagnostic.basinSeparated,
);

const output = {
  schemaVersion: 2,
  model: 'OVMG closed-loop finite-population stress test',
  scope: [
    'Composes normalized gated choice, affine-likelihood moment-matched evidence updates, and persistent adoption--retention.',
    'Does not assume the cubic normal form.',
    'Does not establish empirical fit, general stationary bimodality, or linguistic correctness of h_kappa.',
  ],
  operationalCriteria: {
    endpointConcentration: 'At least 70% of replicate tail means at theta <= 0.2 or theta >= 0.8, no more than 20% in [0.4, 0.6], and at least 15% in each endpoint basin.',
    basinSeparation: 'At least 80% of runs initialized at theta=0.1 remain at or below 0.2 and at least 80% initialized at theta=0.9 remain at or above 0.8.',
    status: 'Finite-horizon diagnostics, not general multimodality or stationary-distribution tests.',
  },
  runSettings: { steps: STEPS, replicates: REPLICATES, seedBase: SEED_BASE },
  diagnosticSummary: {
    linearResponseSeparates: {
      observed: responseFamilies.find(
        (cell) => cell.params.adoptionFamily === 'mean',
      ).basinDiagnostic.basinSeparated,
      interpretation: 'A linear h_kappa supplies no independent threshold nonlinearity.',
    },
    posteriorThresholdSeparates: {
      observed: responseFamilies.find(
        (cell) => cell.params.adoptionFamily === 'posteriorThreshold',
      ).basinDiagnostic.basinSeparated,
      interpretation: 'A concentration-sensitive threshold response can retain low and high coupled states.',
    },
    outsideDominancePreventsEndpointConcentration: {
      observed: !outsideDominated.endpointDiagnostic.endpointConcentrated &&
        outsideDominated.meanFinalConcentration < 8,
      interpretation: 'Observed only for the declared outsideUtility=5 cell; the comparison is not monotonic over all outside utilities.',
    },
    nonlinearAdoptionCanProduceBasinSeparation: {
      observed: nonlinearSeparated.length > 0,
      firstPassingSlope: nonlinearSeparated.length > 0
        ? nonlinearSeparated[0].params.adoptionSlope
        : null,
      interpretation: 'Finite-horizon threshold location in this declared parameter grid, not a universal critical slope.',
    },
    perturbedCoupledStatesReturn: {
      observed: basinReturn.bothReturn,
      interpretation: 'Return after changing inclusion states while preserving their concordant evidence histories.',
    },
    evidenceStatePerturbationsReturn: {
      observed: evidenceStateReturn.bothReturn,
      interpretation: 'Local return after directly perturbing the slow evidence states toward the separatrix.',
    },
  },
  wiringChecks: {
    majorityRepairFlipsTheProgrammedOutcomeAgainstTheBaseline: {
      observed: repairAbsent.endpointDiagnostic.meanTailTheta <= 0.2 &&
        repairPresent.endpointDiagnostic.meanTailTheta >= 0.8,
      interpretation: 'A wiring check for the explicitly majority-amplifying repair convention, not independent support for a repair-controller claim.',
    },
  },
  experiments: {
    responseFamilies,
    outsideOption,
    memoryOpportunity,
    omissionAttributionSensitivity,
    adoptionNonlinearity,
    repairIntervention,
    basinReturn,
    evidenceStateReturn,
    moribundDispersion,
    meanFieldDiagnostics,
  },
};

fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
fs.writeFileSync(OUTPUT_PATH, `${JSON.stringify(output, null, 2)}\n`);
console.log(`Wrote ${OUTPUT_PATH}`);

for (const [section, cells] of Object.entries(output.experiments)) {
  console.log(`\n${section}`);
  if (!Array.isArray(cells)) {
    console.log(JSON.stringify({ ...cells, runs: undefined, arms: cells.arms?.map((arm) => ({
      ...arm, tails: undefined,
    })) }, null, 2));
    continue;
  }
  if (section === 'meanFieldDiagnostics') {
    cells.forEach((cell) => {
      console.log([
        cell.label,
        `fixedPoints=${cell.fixedPoints.length}`,
        `stable=${cell.fixedPoints.filter((point) => point.stable).length}`,
        `theta=${cell.fixedPoints.map((point) => point.theta.toFixed(4)).join(',')}`,
        `spectralRadius=${cell.fixedPoints.map(
          (point) => point.spectralRadius.toFixed(4),
        ).join(',')}`,
      ].join(' | '));
    });
    continue;
  }
  cells.forEach((cell) => {
    const d = cell.endpointDiagnostic;
    const basin = cell.basinDiagnostic;
    console.log([
      cell.label,
      `endpoint=${d.endpointFraction.toFixed(2)}`,
      `central=${d.centralFraction.toFixed(2)}`,
      `lower=${d.lowerFraction.toFixed(2)}`,
      `upper=${d.upperFraction.toFixed(2)}`,
      `endpointCriterion=${d.endpointConcentrated ? 'YES' : 'NO'}`,
      `basinCriterion=${basin ? (basin.basinSeparated ? 'YES' : 'NO') : 'NA'}`,
    ].join(' | '));
  });
}
