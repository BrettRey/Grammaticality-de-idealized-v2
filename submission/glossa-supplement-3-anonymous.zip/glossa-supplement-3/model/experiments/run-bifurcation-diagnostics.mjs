#!/usr/bin/env node
// Refutation-oriented bifurcation diagnostics for the full OVMG mean-field map.
//
// The experiment tests a local saddle-node/cusp hypothesis in the composed
// (theta, a, b) map. It does not fit language data, invoke Thom's gradient
// classification, or treat the scalar cubic in the paper as explanatory.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  deterministicMeanFieldMap,
  eigenvalues3,
  expectedEvidenceFlow,
  findMeanFieldFixedPoints,
  meanFieldJacobian,
  reducedMeanFieldResponse,
  simulateClosedLoop,
  stationaryEvidenceAtTheta,
} from '../js/closed-loop-sim.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUTPUT_PATH = path.resolve(HERE, '../results/bifurcation-diagnostics.json');

const BASE = Object.freeze({
  priorA: 1,
  priorB: 1,
  targetUtility: 0,
  competitorUtility: 0,
  outsideUtility: -4,
  observationProbability: 0.6,
  deltaM: 0.96,
  inclusionUpdateRate: 0.08,
  adoptionFamily: 'posteriorThreshold',
  adoptionThreshold: 0.5,
  majorityRepairProbability: 0,
});

const ROOT_OPTIONS = Object.freeze({
  gridSize: 480,
  tolerance: 1e-11,
  rootTolerance: 1e-10,
  maxIterations: 10000,
});

const MAX_THIRD_MOMENT_ERROR = 1e-3;
const SEED_BASE = 2026082300;

function maxAbs(values) {
  return Math.max(...values.map(Math.abs));
}

function mean(values) {
  return values.reduce((total, value) => total + value, 0) / values.length;
}

function median(values) {
  const ordered = [...values].sort((left, right) => left - right);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 === 1
    ? ordered[middle]
    : (ordered[middle - 1] + ordered[middle]) / 2;
}

function variance(values) {
  const center = mean(values);
  return mean(values.map((value) => (value - center) ** 2));
}

function lagOneAutocorrelation(values) {
  if (values.length < 3) return null;
  const left = values.slice(0, -1);
  const right = values.slice(1);
  const leftMean = mean(left);
  const rightMean = mean(right);
  const covariance = mean(left.map((value, index) => (
    (value - leftMean) * (right[index] - rightMean)
  )));
  const denominator = Math.sqrt(variance(left) * variance(right));
  return denominator > 0 ? covariance / denominator : null;
}

function detrendLinear(values) {
  const n = values.length;
  const centerX = (n - 1) / 2;
  const centerY = mean(values);
  let numerator = 0;
  let denominator = 0;
  values.forEach((value, index) => {
    numerator += (index - centerX) * (value - centerY);
    denominator += (index - centerX) ** 2;
  });
  const slope = denominator > 0 ? numerator / denominator : 0;
  return values.map((value, index) => value - (centerY + slope * (index - centerX)));
}

function linspace(lower, upper, count) {
  return Array.from({ length: count }, (_, index) => (
    lower + (upper - lower) * index / (count - 1)
  ));
}

function solveLinear(matrix, rightHandSide) {
  const size = rightHandSide.length;
  const augmented = matrix.map((row, index) => [...row, rightHandSide[index]]);
  for (let column = 0; column < size; column += 1) {
    let pivot = column;
    for (let row = column + 1; row < size; row += 1) {
      if (Math.abs(augmented[row][column]) > Math.abs(augmented[pivot][column])) {
        pivot = row;
      }
    }
    if (Math.abs(augmented[pivot][column]) < 1e-12) {
      throw new Error('singular numerical Jacobian');
    }
    [augmented[column], augmented[pivot]] = [augmented[pivot], augmented[column]];
    for (let row = column + 1; row < size; row += 1) {
      const factor = augmented[row][column] / augmented[column][column];
      for (let entry = column; entry <= size; entry += 1) {
        augmented[row][entry] -= factor * augmented[column][entry];
      }
    }
  }
  const solution = Array(size).fill(0);
  for (let row = size - 1; row >= 0; row -= 1) {
    let remaining = augmented[row][size];
    for (let column = row + 1; column < size; column += 1) {
      remaining -= augmented[row][column] * solution[column];
    }
    solution[row] = remaining / augmented[row][row];
  }
  return solution;
}

function newtonSystem(initial, equations, {
  finiteSteps,
  tolerance = 1e-8,
  maxIterations = 20,
  valid = () => true,
} = {}) {
  let state = [...initial];
  const trace = [];
  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    const values = equations(state);
    trace.push({ iteration, state: [...state], residual: [...values] });
    if (maxAbs(values) < tolerance) {
      return { converged: true, state, residual: values, iterations: iteration, trace };
    }
    const jacobian = values.map(() => Array(state.length).fill(0));
    state.forEach((_, column) => {
      const step = finiteSteps[column];
      const upper = [...state];
      const lower = [...state];
      upper[column] += step;
      lower[column] -= step;
      const upperValues = equations(upper);
      const lowerValues = equations(lower);
      values.forEach((__, row) => {
        jacobian[row][column] = (upperValues[row] - lowerValues[row]) / (2 * step);
      });
    });
    const update = solveLinear(jacobian, values.map((value) => -value));
    let scale = 1;
    while (!valid(state.map((value, index) => value + scale * update[index])) &&
           scale > 1e-4) {
      scale /= 2;
    }
    if (scale <= 1e-4) {
      return { converged: false, state, residual: values, iterations: iteration, trace,
        reason: 'Newton update left the valid parameter region' };
    }
    state = state.map((value, index) => value + scale * update[index]);
  }
  const residual = equations(state);
  return { converged: maxAbs(residual) < tolerance, state, residual,
    iterations: maxIterations, trace, reason: 'maximum iterations reached' };
}

function paramsAt(inflow, threshold, overrides = {}) {
  return {
    ...BASE,
    opportunitiesPerStep: inflow,
    adoptionThreshold: threshold,
    ...overrides,
  };
}

const residualCache = new Map();

function reducedResidual(theta, inflow, threshold) {
  const key = [theta, inflow, threshold].map((value) => value.toPrecision(15)).join('|');
  if (residualCache.has(key)) return residualCache.get(key);
  const response = reducedMeanFieldResponse(
    theta,
    paramsAt(inflow, threshold),
    { tolerance: 1e-11, maxIterations: 10000 },
  );
  if (!response.converged) throw new Error(response.reason);
  const value = response.response - theta;
  residualCache.set(key, value);
  return value;
}

function thetaDerivatives(theta, inflow, threshold, step = 1e-3) {
  const center = reducedResidual(theta, inflow, threshold);
  const lower = reducedResidual(theta - step, inflow, threshold);
  const upper = reducedResidual(theta + step, inflow, threshold);
  const lowerTwo = reducedResidual(theta - 2 * step, inflow, threshold);
  const upperTwo = reducedResidual(theta + 2 * step, inflow, threshold);
  return {
    residual: center,
    first: (upper - lower) / (2 * step),
    second: (upper - 2 * center + lower) / (step ** 2),
    third: (upperTwo - 2 * upper + 2 * lower - lowerTwo) / (2 * step ** 3),
  };
}

function solveCusp() {
  residualCache.clear();
  const equations = ([theta, inflow, threshold]) => {
    const derivatives = thetaDerivatives(theta, inflow, threshold);
    return [derivatives.residual, derivatives.first, derivatives.second];
  };
  return newtonSystem([0.37, 0.48, 0.552], equations, {
    finiteSteps: [5e-4, 5e-4, 5e-4],
    tolerance: 1e-7,
    valid: ([theta, inflow, threshold]) => (
      theta > 0.01 && theta < 0.99 && inflow > 0.01 &&
      threshold > 0.05 && threshold < 0.95
    ),
  });
}

function solveFold(threshold, initial) {
  residualCache.clear();
  const equations = ([theta, inflow]) => {
    const derivatives = thetaDerivatives(theta, inflow, threshold, 5e-4);
    return [derivatives.residual, derivatives.first];
  };
  return newtonSystem(initial, equations, {
    finiteSteps: [2e-4, 2e-4],
    tolerance: 1e-8,
    valid: ([theta, inflow]) => theta > 0.001 && theta < 0.999 && inflow > 0.001,
  });
}

function controlDerivatives(theta, inflow, threshold, stepScale = 1) {
  const thetaStep = 1e-3;
  const inflowStep = 2e-4 * stepScale;
  const thresholdStep = 2e-4 * stepScale;
  const firstTheta = (candidateInflow, candidateThreshold) => (
    (reducedResidual(theta + thetaStep, candidateInflow, candidateThreshold) -
      reducedResidual(theta - thetaStep, candidateInflow, candidateThreshold)) /
      (2 * thetaStep)
  );
  return {
    residualInflow: (
      reducedResidual(theta, inflow + inflowStep, threshold) -
      reducedResidual(theta, inflow - inflowStep, threshold)
    ) / (2 * inflowStep),
    residualThreshold: (
      reducedResidual(theta, inflow, threshold + thresholdStep) -
      reducedResidual(theta, inflow, threshold - thresholdStep)
    ) / (2 * thresholdStep),
    thetaInflow: (
      firstTheta(inflow + inflowStep, threshold) -
      firstTheta(inflow - inflowStep, threshold)
    ) / (2 * inflowStep),
    thetaThreshold: (
      firstTheta(inflow, threshold + thresholdStep) -
      firstTheta(inflow, threshold - thresholdStep)
    ) / (2 * thresholdStep),
  };
}

function fixedPoints(inflow, threshold, gridSize = ROOT_OPTIONS.gridSize) {
  return findMeanFieldFixedPoints(paramsAt(inflow, threshold), {
    ...ROOT_OPTIONS,
    gridSize,
  });
}

function summarizeFixedPoint(point) {
  return {
    theta: point.theta,
    a: point.a,
    b: point.b,
    evidenceMean: point.evidenceMean,
    concentration: point.concentration,
    stable: point.stable,
    spectralRadius: point.spectralRadius,
    eigenvalues: point.eigenvalues,
    approximationThirdMomentError: point.approximationThirdMomentError,
    approximationVarianceClampApplied: point.approximationVarianceClampApplied,
    approximationVarianceToBernoulliRatioMax:
      point.approximationVarianceToBernoulliRatioMax,
  };
}

function stationaryUniquenessAudit(cells) {
  const starts = [
    { label: 'prior', a: 1, b: 1 },
    { label: 'symmetric-informed', a: 10, b: 10 },
    { label: 'low-skew', a: 1, b: 20 },
    { label: 'high-skew', a: 20, b: 1 },
    { label: 'moderate-skew', a: 2, b: 8 },
  ];
  return cells.map((cell) => {
    const endpoints = starts.map((start) => {
      const result = stationaryEvidenceAtTheta(
        cell.theta,
        paramsAt(cell.inflow, cell.threshold),
        { tolerance: 1e-11, maxIterations: 10000, initialState: start },
      );
      return {
        start: start.label,
        converged: result.converged,
        a: result.state?.a,
        b: result.state?.b,
        approximationThirdMomentError: result.approximationThirdMomentError,
        approximationVarianceClampApplied: result.approximationVarianceClampApplied,
        approximationVarianceToBernoulliRatioMax:
          result.approximationVarianceToBernoulliRatioMax,
      };
    });
    const maximumEndpointDifference = Math.max(
      ...endpoints.flatMap((left) => endpoints.map((right) => Math.max(
        Math.abs(left.a - right.a),
        Math.abs(left.b - right.b),
      ))),
    );
    return { ...cell, endpoints, maximumEndpointDifference,
      uniqueToTolerance: maximumEndpointDifference < 1e-8 };
  });
}

function normalizedDistance(left, right) {
  return Math.sqrt(
    ((left.theta - right.theta) ** 2) +
    ((Math.log(left.a) - Math.log(right.a)) ** 2) +
    ((Math.log(left.b) - Math.log(right.b)) ** 2)
  );
}

function pulseRecovery(point, params) {
  const reference = { theta: point.theta, a: point.a, b: point.b };
  const epsilon = 1e-4;
  const perturbations = [
    { label: 'theta', state: { ...reference, theta: reference.theta + epsilon } },
    { label: 'a', state: { ...reference, a: reference.a * Math.exp(epsilon) } },
    { label: 'b', state: { ...reference, b: reference.b * Math.exp(epsilon) } },
    { label: 'combined', state: {
      theta: reference.theta + epsilon,
      a: reference.a * Math.exp(epsilon),
      b: reference.b * Math.exp(-epsilon),
    } },
  ];
  const results = perturbations.map((perturbation) => {
    let state = perturbation.state;
    const initialDistance = normalizedDistance(state, reference);
    const targetDistance = initialDistance / Math.E;
    let recoveryStep = null;
    for (let step = 1; step <= 5000; step += 1) {
      state = deterministicMeanFieldMap(state, params);
      if (normalizedDistance(state, reference) <= targetDistance) {
        recoveryStep = step;
        break;
      }
    }
    return { label: perturbation.label, initialDistance, recoveryStep };
  });
  return {
    perturbations: results,
    maximumRecoveryStep: Math.max(...results.map((item) => item.recoveryStep ?? 5001)),
  };
}

function criticalSlowingAudit(fold) {
  const ratios = [2.5, 1.5, 1.25, 1.1, 1.05, 1.02];
  return ratios.map((ratio) => {
    const inflow = fold.inflow * ratio;
    const points = fixedPoints(inflow, fold.threshold);
    const lower = points.filter((point) => point.stable)
      .sort((left, right) => left.theta - right.theta)[0];
    if (!lower || points.length < 3) {
      throw new Error(`no lower stable branch at fold ratio ${ratio}`);
    }
    const relaxationTime = -1 / Math.log(lower.spectralRadius);
    return {
      ratio,
      inflow,
      point: summarizeFixedPoint(lower),
      relaxationTimeFromSpectralRadius: relaxationTime,
      pulseRecovery: pulseRecovery(lower, paramsAt(inflow, fold.threshold)),
    };
  });
}

function invertLocalControls(unfolding, coefficient, bias) {
  const matrix = [
    [unfolding.thetaInflow, unfolding.thetaThreshold],
    [unfolding.residualInflow, unfolding.residualThreshold],
  ];
  const [deltaInflow, deltaThreshold] = solveLinear(matrix, [coefficient, bias]);
  return { deltaInflow, deltaThreshold };
}

function solveConstrainedFold(cusp, unfolding, coefficient, initial) {
  residualCache.clear();
  const equations = ([theta, inflow, threshold]) => {
    const derivatives = thetaDerivatives(theta, inflow, threshold, 5e-4);
    const deltaInflow = inflow - cusp.inflow;
    const deltaThreshold = threshold - cusp.threshold;
    const localCoefficient = unfolding.thetaInflow * deltaInflow +
      unfolding.thetaThreshold * deltaThreshold;
    return [derivatives.residual, derivatives.first, localCoefficient - coefficient];
  };
  return newtonSystem(initial, equations, {
    finiteSteps: [2e-4, 2e-4, 2e-4],
    tolerance: 1e-8,
    valid: ([theta, inflow, threshold]) => (
      theta > 0.001 && theta < 0.999 && inflow > 0.001 &&
      threshold > 0.05 && threshold < 0.95
    ),
  });
}

function iterateAtControls(state, inflow, threshold, iterations) {
  let current = state;
  const params = paramsAt(inflow, threshold);
  for (let iteration = 0; iteration < iterations; iteration += 1) {
    current = deterministicMeanFieldMap(current, params);
  }
  return { theta: current.theta, a: current.a, b: current.b };
}

function largestJump(rows) {
  let result = null;
  for (let index = 1; index < rows.length; index += 1) {
    const jump = Math.abs(rows[index].theta - rows[index - 1].theta);
    if (!result || jump > result.size) {
      result = {
        size: jump,
        fromBias: rows[index - 1].bias,
        toBias: rows[index].bias,
        fromTheta: rows[index - 1].theta,
        toTheta: rows[index].theta,
      };
    }
  }
  return result;
}

function hysteresisAudit(cusp, unfolding) {
  const coefficient = 0.02;
  const seedBias = 0.001;
  const lowerSeedControls = invertLocalControls(unfolding, coefficient, -seedBias);
  const upperSeedControls = invertLocalControls(unfolding, coefficient, seedBias);
  const lowerFoldResult = solveConstrainedFold(cusp, unfolding, coefficient, [
    cusp.theta - 0.08,
    cusp.inflow + lowerSeedControls.deltaInflow,
    cusp.threshold + lowerSeedControls.deltaThreshold,
  ]);
  const upperFoldResult = solveConstrainedFold(cusp, unfolding, coefficient, [
    cusp.theta + 0.08,
    cusp.inflow + upperSeedControls.deltaInflow,
    cusp.threshold + upperSeedControls.deltaThreshold,
  ]);
  if (!lowerFoldResult.converged || !upperFoldResult.converged) {
    throw new Error('failed to locate both folds on the cusp cross-section');
  }
  const foldRows = [lowerFoldResult, upperFoldResult].map((result) => {
    const [theta, inflow, threshold] = result.state;
    const deltaInflow = inflow - cusp.inflow;
    const deltaThreshold = threshold - cusp.threshold;
    return {
      theta,
      inflow,
      threshold,
      coefficient: unfolding.thetaInflow * deltaInflow +
        unfolding.thetaThreshold * deltaThreshold,
      bias: unfolding.residualInflow * deltaInflow +
        unfolding.residualThreshold * deltaThreshold,
      residual: result.residual,
    };
  }).sort((left, right) => left.bias - right.bias);
  const biasExtent = 1.8 * Math.max(...foldRows.map((row) => Math.abs(row.bias)));
  const upwardBiases = linspace(-biasExtent, biasExtent, 81);
  const downwardBiases = [...upwardBiases].reverse();
  const startControls = invertLocalControls(unfolding, coefficient, upwardBiases[0]);
  const startInflow = cusp.inflow + startControls.deltaInflow;
  const startThreshold = cusp.threshold + startControls.deltaThreshold;
  const startPoints = fixedPoints(startInflow, startThreshold, 720);
  if (startPoints.length !== 1) {
    throw new Error(`hysteresis path must begin with one fixed point, got ${startPoints.length}`);
  }
  const startState = {
    theta: startPoints[0].theta,
    a: startPoints[0].a,
    b: startPoints[0].b,
  };
  const rates = [20, 100, 1000, 5000, 10000].map((iterationsPerValue) => {
    let state = startState;
    const runDirection = (biases) => biases.map((bias) => {
      const controls = invertLocalControls(unfolding, coefficient, bias);
      const inflow = cusp.inflow + controls.deltaInflow;
      const threshold = cusp.threshold + controls.deltaThreshold;
      state = iterateAtControls(state, inflow, threshold, iterationsPerValue);
      return { bias, inflow, threshold, ...state };
    });
    const upward = runDirection(upwardBiases);
    const downward = runDirection(downwardBiases);
    const downwardAscending = [...downward].reverse();
    let loopArea = 0;
    for (let index = 1; index < upward.length; index += 1) {
      const width = upward[index].bias - upward[index - 1].bias;
      const previousDifference = Math.abs(
        upward[index - 1].theta - downwardAscending[index - 1].theta,
      );
      const difference = Math.abs(upward[index].theta - downwardAscending[index].theta);
      loopArea += width * (previousDifference + difference) / 2;
    }
    const upwardJump = largestJump(upward);
    const downwardJump = largestJump(downward);
    return {
      iterationsPerValue,
      upward,
      downward,
      upwardJump,
      downwardJump,
      upwardStaticFoldError: Math.abs(upwardJump.toBias - foldRows.at(-1).bias),
      downwardStaticFoldError: Math.abs(downwardJump.toBias - foldRows[0].bias),
      loopArea,
    };
  });
  return {
    localCoefficient: coefficient,
    staticFolds: foldRows,
    biasExtent,
    rates,
    interpretation: [
      'The two-control path holds the local splitting coefficient fixed and sweeps the independent bias coordinate.',
      'Distinct limiting jumps constitute static cusp hysteresis; rate-dependent displacement is dynamic lag.',
    ],
  };
}

function stochasticSlowingAudit(fold) {
  const ratios = [2.5, 1.5, 1.1, 1.02];
  const replicates = 24;
  const steps = 3000;
  const burnIn = 500;
  return ratios.map((ratio, ratioIndex) => {
    const deterministicInflow = fold.inflow * ratio;
    const points = fixedPoints(deterministicInflow, fold.threshold);
    const stable = points.filter((point) => point.stable)
      .sort((left, right) => left.theta - right.theta);
    const lower = stable[0];
    const unstable = points.find((point) => !point.stable);
    if (!lower || !unstable) throw new Error(`missing branches for stochastic ratio ${ratio}`);
    const observationProbability = deterministicInflow * BASE.observationProbability;
    if (observationProbability > 1) {
      throw new Error(`stochastic observation probability exceeds one at ratio ${ratio}`);
    }
    const runs = [];
    for (let replicate = 0; replicate < replicates; replicate += 1) {
      const run = simulateClosedLoop({
        ...BASE,
        speakerCount: 240,
        opportunitiesPerStep: 1,
        observationProbability,
        adoptionThreshold: fold.threshold,
        initialInclusionRate: lower.theta,
        initialEvidenceState: { a: lower.a, b: lower.b },
      }, steps, SEED_BASE + ratioIndex * 100 + replicate);
      const escapeRow = run.rows.find((row) => row.step >= burnIn && row.theta > unstable.theta);
      const analysisEnd = escapeRow ? escapeRow.step - 1 : steps;
      const analysisRows = run.rows.filter((row) => (
        row.step >= burnIn && row.step <= analysisEnd
      ));
      const theta = analysisRows.map((row) => row.theta);
      const residualTheta = theta.length >= 200 ? detrendLinear(theta) : [];
      runs.push({
        seed: SEED_BASE + ratioIndex * 100 + replicate,
        escaped: Boolean(escapeRow),
        escapeStep: escapeRow?.step ?? null,
        analyzedSteps: theta.length,
        variance: theta.length >= 200 ? variance(theta) : null,
        detrendedVariance: residualTheta.length > 0 ? variance(residualTheta) : null,
        detrendedLagOneAutocorrelation: residualTheta.length > 0
          ? lagOneAutocorrelation(residualTheta)
          : null,
        maximumThirdMomentError: Math.max(...run.rows.map(
          (row) => row.approximationThirdMomentErrorMax,
        )),
        anyVarianceClamp: run.rows.some(
          (row) => row.approximationVarianceClampFraction > 0,
        ),
        maximumVarianceToBernoulliRatio: Math.max(...run.rows.map(
          (row) => row.approximationVarianceToBernoulliRatioMax,
        )),
      });
    }
    const valid = runs.filter((run) => run.detrendedLagOneAutocorrelation !== null);
    return {
      ratio,
      deterministicInflow,
      observationProbability,
      lowerFixedPoint: summarizeFixedPoint(lower),
      unstableTheta: unstable.theta,
      replicateCount: replicates,
      validReplicateCount: valid.length,
      escapeFraction: runs.filter((run) => run.escaped).length / runs.length,
      medianVariance: valid.length > 0 ? median(valid.map((run) => run.variance)) : null,
      medianDetrendedVariance: valid.length > 0
        ? median(valid.map((run) => run.detrendedVariance))
        : null,
      medianDetrendedLagOneAutocorrelation: valid.length > 0
        ? median(valid.map((run) => run.detrendedLagOneAutocorrelation))
        : null,
      runs,
    };
  });
}

const preemptionSanity = expectedEvidenceFlow({ theta: 0.5, outsideUtility: -4 });
if (!(preemptionSanity.omissionAvailabilityContrast > 0)) {
  throw new Error('declared preemptive cell must have a positive omission contrast');
}

const cuspResult = solveCusp();
if (!cuspResult.converged) throw new Error(`cusp solve failed: ${cuspResult.reason}`);
const [cuspTheta, cuspInflow, cuspThreshold] = cuspResult.state;
const cusp = { theta: cuspTheta, inflow: cuspInflow, threshold: cuspThreshold };
residualCache.clear();
const cuspDerivatives = thetaDerivatives(cuspTheta, cuspInflow, cuspThreshold, 1e-3);
const cuspDerivativeStepAudit = [5e-4, 1e-3, 2e-3, 4e-3].map((step) => ({
  step,
  ...thetaDerivatives(cuspTheta, cuspInflow, cuspThreshold, step),
}));
const unfolding = controlDerivatives(cuspTheta, cuspInflow, cuspThreshold);
unfolding.determinant = unfolding.residualInflow * unfolding.thetaThreshold -
  unfolding.residualThreshold * unfolding.thetaInflow;
const unfoldingStepAudit = [0.5, 1, 2, 4].map((stepScale) => {
  const derivatives = controlDerivatives(
    cuspTheta,
    cuspInflow,
    cuspThreshold,
    stepScale,
  );
  return {
    stepScale,
    ...derivatives,
    determinant: derivatives.residualInflow * derivatives.thetaThreshold -
      derivatives.residualThreshold * derivatives.thetaInflow,
  };
});
const cuspStationary = stationaryEvidenceAtTheta(
  cuspTheta,
  paramsAt(cuspInflow, cuspThreshold),
  { tolerance: 1e-11, maxIterations: 10000 },
);
const cuspState = { theta: cuspTheta, a: cuspStationary.state.a, b: cuspStationary.state.b };
const cuspJacobian = meanFieldJacobian(cuspState, paramsAt(cuspInflow, cuspThreshold), 1e-6);
const cuspEigenvalues = eigenvalues3(cuspJacobian);

const foldResult = solveFold(0.5, [0.157, 0.655]);
if (!foldResult.converged) throw new Error(`fold solve failed: ${foldResult.reason}`);
const [foldTheta, foldInflow] = foldResult.state;
const fold = { theta: foldTheta, inflow: foldInflow, threshold: 0.5 };

const insideControls = invertLocalControls(unfolding, 0.02, 0);
const cuspNeighborhood = [
  { label: 'cusp-center', inflow: cusp.inflow, threshold: cusp.threshold },
  { label: 'inside-cusp-wedge',
    inflow: cusp.inflow + insideControls.deltaInflow,
    threshold: cusp.threshold + insideControls.deltaThreshold },
  { label: 'outside-cusp-wedge', inflow: cusp.inflow + 0.01, threshold: cusp.threshold },
].map((cell) => {
  const points = fixedPoints(cell.inflow, cell.threshold, 960).map(summarizeFixedPoint);
  const groupedTheta = points.reduce((groups, point) => {
    if (groups.length === 0 || Math.abs(point.theta - groups.at(-1)) > 0.01) {
      groups.push(point.theta);
    }
    return groups;
  }, []);
  return {
    ...cell,
    fixedPoints: points,
    distinctFixedPointCount: cell.label === 'cusp-center' ? 1 : groupedTheta.length,
    numericalNote: cell.label === 'cusp-center'
      ? 'The derivative conditions establish one triple root; a sign-change locator can numerically split it into nearby simple roots.'
      : null,
  };
});

const stationarityAudit = stationaryUniquenessAudit([
  cusp,
  ...cuspNeighborhood.flatMap((cell) => cell.fixedPoints.map((point) => ({
    theta: point.theta,
    inflow: cell.inflow,
    threshold: cell.threshold,
  }))),
]);

const criticalSlowing = criticalSlowingAudit(fold);
const hysteresis = hysteresisAudit(cusp, unfolding);
const stochasticSlowing = stochasticSlowingAudit(fold);

const shapePoints = [
  ...cuspNeighborhood.flatMap((cell) => cell.fixedPoints.map((point) => ({
    source: cell.label,
    inflow: cell.inflow,
    threshold: cell.threshold,
    ...point,
  }))),
  ...criticalSlowing.map((row) => ({
    source: `fold-ratio-${row.ratio}`,
    inflow: row.inflow,
    threshold: fold.threshold,
    ...row.point,
  })),
  ...fixedPoints(12, 0.5).map((point) => ({
    source: 'declared-base-cell',
    inflow: 12,
    threshold: 0.5,
    ...summarizeFixedPoint(point),
  })),
];
const betaShapeAudit = {
  minimumA: Math.min(...shapePoints.map((point) => point.a)),
  minimumB: Math.min(...shapePoints.map((point) => point.b)),
  oneShapeBelowOneCount: shapePoints.filter((point) => (
    (point.a < 1) !== (point.b < 1)
  )).length,
  bothShapesBelowOneCount: shapePoints.filter((point) => point.a < 1 && point.b < 1).length,
  points: shapePoints,
  interpretation: [
    'A quiet niche returns to the registered Beta(1,1) baseline and does not generate a U-shaped posterior.',
    'Dense negative-evidence branches can moment-match to one shape parameter slightly below one, producing one-sided boundary mass rather than a U shape.',
    'Mean and concentration still determine both Beta shape parameters, so this is not a hidden state regime.',
  ],
};

const deterministicClampObserved = shapePoints.some(
  (point) => point.approximationVarianceClampApplied,
);
const stationarityUnique = stationarityAudit.every((cell) => cell.uniqueToTolerance);
const stochasticClampObserved = stochasticSlowing.some((cell) => (
  cell.runs.some((run) => run.anyVarianceClamp)
));
const stochasticMedians = stochasticSlowing.map((cell) => ({
  ratio: cell.ratio,
  lagOne: cell.medianDetrendedLagOneAutocorrelation,
  variance: cell.medianDetrendedVariance,
}));
const orderedNearFold = [...stochasticMedians].sort((left, right) => right.ratio - left.ratio);
const lagOneRisesTowardFold = orderedNearFold.every((cell, index) => (
  index === 0 || cell.lagOne >= orderedNearFold[index - 1].lagOne
));
const varianceRisesTowardFold = orderedNearFold.every((cell, index) => (
  index === 0 || cell.variance >= orderedNearFold[index - 1].variance
));
const stochasticValidAtEveryRatio = stochasticSlowing.every(
  (cell) => cell.validReplicateCount >= 12,
);
const slowestHysteresis = hysteresis.rates.at(-1);
const hysteresisRateConverges = slowestHysteresis.upwardStaticFoldError < 2e-4 &&
  slowestHysteresis.downwardStaticFoldError < 2e-4 &&
  slowestHysteresis.upwardJump.size > 0.05 &&
  slowestHysteresis.downwardJump.size > 0.05;

const output = {
  schemaVersion: 1,
  model: 'OVMG full-map bifurcation diagnostics',
  scope: [
    'Tests local fixed-point geometry, full-map stability, deterministic hysteresis, and finite-population slowing.',
    'Uses effective evidence inflow and the independently motivated adoption threshold as controls.',
    'Does not establish empirical fit, linguistic truth, a global potential, or Thom-style catastrophe classification.',
  ],
  preregisteredFailureConditions: {
    cuspResidualTolerance: 1e-7,
    cuspThirdDerivativeMustBeNonzero: true,
    unfoldingDeterminantMustBeNonzero: true,
    noncenterEigenvaluesMustRemainInsideUnitCircle: true,
    stationaryEvidenceMustBeUniqueTo: 1e-8,
    varianceClampMayNotBind: true,
    maximumThirdMomentError: MAX_THIRD_MOMENT_ERROR,
    minimumValidStochasticReplicatesPerCell: 12,
    stochasticCriticalSlowingExpectation:
      'Median detrended variance and lag-1 autocorrelation rise monotonically as the lower branch approaches the q=0.5 fold.',
    stochasticInflowFactorization:
      'One opportunity per step with observation probability equal to effective observed inflow; invariance to other opportunity/observation factorizations is not assumed.',
  },
  baseParameters: BASE,
  preemptionSanity,
  cusp: {
    ...cusp,
    effectiveObservedInflow: cusp.inflow * BASE.observationProbability,
    state: cuspState,
    solverResidual: cuspResult.residual,
    thetaDerivatives: cuspDerivatives,
    derivativeStepAudit: cuspDerivativeStepAudit,
    unfolding,
    unfoldingStepAudit,
    jacobian: cuspJacobian,
    eigenvalues: cuspEigenvalues,
    localConditionsPass: maxAbs(cuspResult.residual) < 1e-7 &&
      Math.abs(cuspDerivatives.third) > 1e-2 &&
      Math.abs(unfolding.determinant) > 1e-2 &&
      unfoldingStepAudit.every((row) => Math.abs(row.determinant) > 1e-2) &&
      Math.abs(cuspEigenvalues[0].modulus - 1) < 1e-5 &&
      cuspEigenvalues.slice(1).every((value) => value.modulus < 1),
  },
  qPointFiveFold: {
    ...fold,
    effectiveObservedInflow: fold.inflow * BASE.observationProbability,
    solverResidual: foldResult.residual,
  },
  cuspNeighborhood,
  stationarityAudit,
  betaShapeAudit,
  criticalSlowing,
  hysteresis,
  stochasticSlowing,
  diagnosticSummary: {
    cuspLocalConditionsPass: maxAbs(cuspResult.residual) < 1e-7 &&
      Math.abs(cuspDerivatives.third) > 1e-2 &&
      Math.abs(unfolding.determinant) > 1e-2 &&
      unfoldingStepAudit.every((row) => Math.abs(row.determinant) > 1e-2) &&
      cuspEigenvalues.slice(1).every((value) => value.modulus < 1),
    oneVersusThreeFixedPointsObserved:
      cuspNeighborhood.find((cell) => cell.label === 'outside-cusp-wedge')
        .distinctFixedPointCount === 1 &&
      cuspNeighborhood.find((cell) => cell.label === 'inside-cusp-wedge')
        .distinctFixedPointCount === 3,
    stationaryEvidenceUnique: stationarityUnique,
    deterministicVarianceClampObserved: deterministicClampObserved,
    stochasticVarianceClampObserved: stochasticClampObserved,
    maximumDeterministicThirdMomentError: Math.max(...shapePoints.map(
      (point) => point.approximationThirdMomentError,
    )),
    stochasticLagOneRisesTowardFold: lagOneRisesTowardFold,
    stochasticVarianceRisesTowardFold: varianceRisesTowardFold,
    stochasticValidAtEveryRatio,
    stochasticResultPasses: lagOneRisesTowardFold && varianceRisesTowardFold &&
      stochasticValidAtEveryRatio,
    hysteresisRateConverges,
    manuscriptInterpretation: [
      'A local cusp bifurcation is supported in the expected-window closure under two independently interpretable controls.',
      'The result licenses local bifurcation and hysteresis language, not Thom catastrophe classification or empirical claims about language.',
      'The scalar cubic cannot represent this interior three-root geometry.',
    ],
  },
};

fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
fs.writeFileSync(OUTPUT_PATH, `${JSON.stringify(output, null, 2)}\n`);

console.log(`Wrote ${OUTPUT_PATH}`);
console.log(`cusp theta=${cusp.theta.toFixed(6)} inflow=${cusp.inflow.toFixed(6)} q=${cusp.threshold.toFixed(6)}`);
console.log(`cusp eigenvalues=${cuspEigenvalues.map((value) => value.modulus.toFixed(6)).join(',')}`);
console.log(`unfolding determinant=${unfolding.determinant.toFixed(6)} third=${cuspDerivatives.third.toFixed(6)}`);
console.log(`q=.5 fold inflow=${fold.inflow.toFixed(6)}`);
console.log(`shape minima a=${betaShapeAudit.minimumA.toFixed(6)} b=${betaShapeAudit.minimumB.toFixed(6)} both<1=${betaShapeAudit.bothShapesBelowOneCount}`);
criticalSlowing.forEach((row) => console.log(
  `slowing ratio=${row.ratio} rho=${row.point.spectralRadius.toFixed(6)} tau=${row.relaxationTimeFromSpectralRadius.toFixed(1)} pulse=${row.pulseRecovery.maximumRecoveryStep}`,
));
hysteresis.rates.forEach((row) => console.log(
  `hysteresis k=${row.iterationsPerValue} up=${row.upwardJump.toBias.toExponential(3)} down=${row.downwardJump.toBias.toExponential(3)} errors=${row.upwardStaticFoldError.toExponential(2)}/${row.downwardStaticFoldError.toExponential(2)} area=${row.loopArea.toExponential(3)}`,
));
stochasticSlowing.forEach((row) => console.log(
  `stochastic ratio=${row.ratio} valid=${row.validReplicateCount}/${row.replicateCount} escape=${row.escapeFraction.toFixed(2)} variance=${row.medianDetrendedVariance?.toExponential(3)} ac1=${row.medianDetrendedLagOneAutocorrelation?.toFixed(4)}`,
));
console.log(`stochastic slowing criterion=${output.diagnosticSummary.stochasticResultPasses ? 'PASS' : 'FAIL'}`);
