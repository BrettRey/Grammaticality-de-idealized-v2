// closed-loop-sim.mjs -- finite-population stress test for the current OVMG model.
//
// This module closes the loop that revised-sim.mjs intentionally leaves open:
// population inclusion states generate choices, observed choices update each
// speaker's evidence filter, and those filters enter the paper's persistent
// adoption--retention transition. It does not assume the cubic normal form and
// does not claim that any response family below is empirically established.

import {
  availabilityPowerPosteriorUpdate,
  availabilityPosteriorUpdate,
  gatedChoiceProbabilities,
  makeEvidenceState,
  mean,
  omissionEvidenceFromChoice,
  posteriorProbabilityAtLeast,
  summary,
} from './revised-engine.mjs';
import { mulberry32 } from './revised-sim.mjs';

export const ADOPTION_FAMILIES = Object.freeze([
  'mean',
  'logisticMean',
  'posteriorThreshold',
]);

function requireFinite(value, name) {
  if (!Number.isFinite(value)) {
    throw new TypeError(`${name} must be finite, got ${value}`);
  }
}

function requireProbability(value, name) {
  requireFinite(value, name);
  if (value < 0 || value > 1) {
    throw new RangeError(`${name} must be in [0, 1], got ${value}`);
  }
}

function requireNonnegative(value, name) {
  requireFinite(value, name);
  if (value < 0) throw new RangeError(`${name} must be non-negative, got ${value}`);
}

function logistic(value) {
  if (value >= 0) {
    const inverse = Math.exp(-value);
    return 1 / (1 + inverse);
  }
  const direct = Math.exp(value);
  return direct / (1 + direct);
}

/**
 * Candidate adoption--retention responses for h_kappa in the manuscript's
 * inclusion transition. Comparing them is part of the stress test.
 *
 * - mean: adoption tracks the posterior mean without a categorical response.
 * - logisticMean: a smooth threshold response to the posterior mean.
 * - posteriorThreshold: adoption tracks posterior mass above the independently
 *   supplied membership threshold and therefore uses concentration as well.
 */
export function adoptionProbability(state, {
  family = 'mean',
  threshold = 0.5,
  slope = 8,
} = {}) {
  if (!ADOPTION_FAMILIES.includes(family)) {
    throw new RangeError(`unknown adoption family ${family}`);
  }
  requireProbability(threshold, 'threshold');
  requireNonnegative(slope, 'slope');
  if (family === 'mean') return mean(state);
  if (family === 'logisticMean') {
    return logistic(slope * (mean(state) - threshold));
  }
  return posteriorProbabilityAtLeast(state, threshold);
}

/**
 * Expected observation quantities per niche occasion at a specified
 * population inclusion rate, before observation thinning. These are not
 * additive positive and negative pseudo-count flows. The exact batch update
 * uses a target factor `theta` and an affine omission factor `1 - d * theta`.
 */
export function expectedEvidenceFlow({
  theta,
  targetUtility = 0,
  competitorUtility = 0,
  outsideUtility = -4,
  recoverability = 1,
  omissionAttribution = 1,
} = {}) {
  requireProbability(theta, 'theta');
  requireProbability(recoverability, 'recoverability');
  requireProbability(omissionAttribution, 'omissionAttribution');
  const utilities = [targetUtility, competitorUtility];
  const availableProbabilities = gatedChoiceProbabilities({
    utilities,
    availability: [true, true],
    outsideUtility,
  });
  const targetProbabilityIfIncluded = availableProbabilities.candidates[0];
  const omission = omissionEvidenceFromChoice({
    utilities,
    availability: [false, true],
    targetIndex: 0,
    observedOutcome: 1,
    outsideUtility,
    recoverability,
  });
  const targetOutcomeProbability = theta * targetProbabilityIfIncluded;
  const nonTargetOutcomeProbability = 1 - targetOutcomeProbability;
  const omissionAvailabilityContrast = omissionAttribution *
    omission.availabilityContrast;
  return {
    theta,
    targetProbabilityIfIncluded,
    omissionLogLikelihoodRatio: omission.logLikelihoodRatio,
    omissionAvailabilityContrast,
    targetOutcomeProbability,
    nonTargetOutcomeProbability,
    expectedOmissionContrast: nonTargetOutcomeProbability * omissionAvailabilityContrast,
  };
}

function deterministicEvidenceUpdateAtTheta(theta, state, params = {}) {
  const {
    targetUtility = 0,
    competitorUtility = 0,
    outsideUtility = -4,
    opportunitiesPerStep = 12,
    observationProbability = 0.6,
    deltaM = 0.96,
    targetEvidenceWeight = 1,
    omissionAttribution = 1,
    recoverability = 1,
  } = params;
  requireProbability(theta, 'theta');
  requireNonnegative(opportunitiesPerStep, 'opportunitiesPerStep');
  requireProbability(observationProbability, 'observationProbability');
  requireNonnegative(targetEvidenceWeight, 'targetEvidenceWeight');
  const flow = expectedEvidenceFlow({
    theta,
    targetUtility,
    competitorUtility,
    outsideUtility,
    recoverability,
    omissionAttribution,
  });
  const observedOpportunities = opportunitiesPerStep * observationProbability;
  return availabilityPowerPosteriorUpdate(state, {
    targetPower: targetEvidenceWeight * observedOpportunities *
      flow.targetOutcomeProbability,
    omissionContrast: flow.omissionAvailabilityContrast,
    omissionPower: observedOpportunities * flow.nonTargetOutcomeProbability,
  }, { deltaM });
}

/**
 * Deterministic expected-batch closure for the coupled `(theta, a, b)` state.
 * It is a diagnostic approximation to the finite-population process, not the
 * stochastic simulator's transition kernel.
 */
export function deterministicMeanFieldMap(state, params = {}) {
  const { theta, a, b } = state;
  const {
    priorA = 1,
    priorB = 1,
    inclusionUpdateRate = 0.08,
    adoptionFamily = 'posteriorThreshold',
    adoptionThreshold = 0.5,
    adoptionSlope = 8,
    majorityRepairProbability = 0,
  } = params;
  requireProbability(theta, 'theta');
  if (!(a > 0) || !(b > 0)) throw new RangeError(`a and b must be positive, got ${a}, ${b}`);
  requireProbability(inclusionUpdateRate, 'inclusionUpdateRate');
  if (majorityRepairProbability !== 0) {
    throw new RangeError('deterministic mean-field map excludes the repair wiring intervention');
  }
  const currentEvidence = makeEvidenceState({ priorA, priorB, a, b });
  const update = deterministicEvidenceUpdateAtTheta(theta, currentEvidence, params);
  const response = {
    family: adoptionFamily,
    threshold: adoptionThreshold,
    slope: adoptionSlope,
  };
  const adoption = adoptionProbability(update.state, response);
  return {
    theta: (1 - inclusionUpdateRate) * theta + inclusionUpdateRate * adoption,
    a: update.state.a,
    b: update.state.b,
    adoptionProbability: adoption,
    approximationThirdMomentError: update.approximation.absoluteThirdMomentError,
    approximationVarianceClampApplied: update.approximation.varianceClampApplied,
    approximationVarianceToBernoulliRatio:
      update.approximation.varianceToBernoulliRatio,
  };
}

/** Numerical Jacobian of the full deterministic `(theta, a, b)` map. */
export function meanFieldJacobian(state, params = {}, relativeStep = 1e-5) {
  if (!(relativeStep > 0)) throw new RangeError('relativeStep must be positive');
  const names = ['theta', 'a', 'b'];
  const matrix = Array.from({ length: 3 }, () => Array(3).fill(0));
  names.forEach((name, column) => {
    const scale = Math.max(1, Math.abs(state[name]));
    let step = relativeStep * scale;
    if (name !== 'theta') step = Math.min(step, state[name] / 2);
    const useForward = name === 'theta' && state.theta - step < 0;
    const useBackward = name === 'theta' && state.theta + step > 1;
    const lower = { ...state, [name]: useForward ? state[name] : state[name] - step };
    const upper = { ...state, [name]: useBackward ? state[name] : state[name] + step };
    const lowerMap = deterministicMeanFieldMap(lower, params);
    const upperMap = deterministicMeanFieldMap(upper, params);
    const denominator = upper[name] - lower[name];
    names.forEach((outputName, row) => {
      matrix[row][column] = (upperMap[outputName] - lowerMap[outputName]) / denominator;
    });
  });
  return matrix;
}

function determinant3(matrix) {
  return matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1]) -
    matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0]) +
    matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]);
}

function complexSubtract(left, right) {
  return { re: left.re - right.re, im: left.im - right.im };
}

function complexMultiply(left, right) {
  return {
    re: left.re * right.re - left.im * right.im,
    im: left.re * right.im + left.im * right.re,
  };
}

function complexDivide(left, right) {
  const denominator = right.re ** 2 + right.im ** 2;
  return {
    re: (left.re * right.re + left.im * right.im) / denominator,
    im: (left.im * right.re - left.re * right.im) / denominator,
  };
}

function evaluateMonicCubic(root, coefficients) {
  let value = { re: 1, im: 0 };
  coefficients.forEach((coefficient) => {
    value = complexMultiply(value, root);
    value.re += coefficient;
  });
  return value;
}

/** Eigenvalues of a real 3x3 matrix, returned with complex moduli. */
export function eigenvalues3(matrix) {
  if (!Array.isArray(matrix) || matrix.length !== 3 ||
      matrix.some((row) => !Array.isArray(row) || row.length !== 3)) {
    throw new RangeError('matrix must be 3x3');
  }
  const trace = matrix[0][0] + matrix[1][1] + matrix[2][2];
  const traceSquare = (
    matrix[0][0] ** 2 + matrix[1][1] ** 2 + matrix[2][2] ** 2 +
    2 * (matrix[0][1] * matrix[1][0] + matrix[0][2] * matrix[2][0] +
      matrix[1][2] * matrix[2][1])
  );
  const secondCoefficient = 0.5 * ((trace ** 2) - traceSquare);
  const coefficients = [-trace, secondCoefficient, -determinant3(matrix)];
  const radius = 1 + Math.max(...coefficients.map(Math.abs));
  let roots = Array.from({ length: 3 }, (_, index) => ({
    re: radius * Math.cos((2 * Math.PI * index) / 3 + 0.17),
    im: radius * Math.sin((2 * Math.PI * index) / 3 + 0.17),
  }));
  for (let iteration = 0; iteration < 200; iteration += 1) {
    let largestChange = 0;
    const nextRoots = roots.map((root, index) => {
      let denominator = { re: 1, im: 0 };
      roots.forEach((other, otherIndex) => {
        if (otherIndex !== index) {
          denominator = complexMultiply(denominator, complexSubtract(root, other));
        }
      });
      const correction = complexDivide(evaluateMonicCubic(root, coefficients), denominator);
      largestChange = Math.max(largestChange, Math.hypot(correction.re, correction.im));
      return complexSubtract(root, correction);
    });
    roots = nextRoots;
    if (largestChange < 1e-12) break;
  }
  return roots.map((root) => ({
    re: Math.abs(root.re) < 1e-12 ? 0 : root.re,
    im: Math.abs(root.im) < 1e-12 ? 0 : root.im,
    modulus: Math.hypot(root.re, root.im),
  })).sort((left, right) => right.modulus - left.modulus);
}

/** Stationary evidence state when the population rate is externally fixed. */
export function stationaryEvidenceAtTheta(theta, params = {}, options = {}) {
  const { priorA = 1, priorB = 1, deltaM = 0.96 } = params;
  const { tolerance = 1e-10, maxIterations = 5000, initialState = null } = options;
  if (!(deltaM < 1)) {
    return { converged: false, reason: 'deltaM=1 has no finite stationary concentration' };
  }
  let state = initialState
    ? makeEvidenceState({ priorA, priorB, a: initialState.a, b: initialState.b })
    : makeEvidenceState({ priorA, priorB });
  let approximationThirdMomentError = 0;
  let approximationVarianceClampApplied = false;
  let approximationVarianceToBernoulliRatioMax = 0;
  for (let iteration = 1; iteration <= maxIterations; iteration += 1) {
    const update = deterministicEvidenceUpdateAtTheta(theta, state, params);
    approximationThirdMomentError = update.approximation.absoluteThirdMomentError;
    approximationVarianceClampApplied ||= update.approximation.varianceClampApplied;
    approximationVarianceToBernoulliRatioMax = Math.max(
      approximationVarianceToBernoulliRatioMax,
      update.approximation.varianceToBernoulliRatio,
    );
    const change = Math.max(
      Math.abs(update.state.a - state.a),
      Math.abs(update.state.b - state.b),
    );
    state = update.state;
    if (change < tolerance) {
      return {
        converged: true,
        iterations: iteration,
        state,
        approximationThirdMomentError,
        approximationVarianceClampApplied,
        approximationVarianceToBernoulliRatioMax,
      };
    }
  }
  return { converged: false, reason: `no convergence in ${maxIterations} iterations`, state };
}

/** Reduced response H(theta), used to locate—not time—full-map equilibria. */
export function reducedMeanFieldResponse(theta, params = {}, options = {}) {
  const stationary = stationaryEvidenceAtTheta(theta, params, options);
  if (!stationary.converged) return { ...stationary, theta, response: null };
  const response = adoptionProbability(stationary.state, {
    family: params.adoptionFamily ?? 'posteriorThreshold',
    threshold: params.adoptionThreshold ?? 0.5,
    slope: params.adoptionSlope ?? 8,
  });
  return { ...stationary, theta, response };
}

/** Locate reduced crossings and classify them with the full 3x3 Jacobian. */
export function findMeanFieldFixedPoints(params = {}, options = {}) {
  const { gridSize = 160, rootTolerance = 1e-8 } = options;
  if (!Number.isInteger(gridSize) || gridSize < 8) {
    throw new RangeError('gridSize must be an integer of at least 8');
  }
  const evaluate = (theta) => {
    const result = reducedMeanFieldResponse(theta, params, options);
    if (!result.converged) throw new Error(result.reason);
    return { ...result, residual: result.response - theta };
  };
  const lowerBound = 0;
  const upperBound = 1;
  const edge = Array.from({ length: 12 }, (_, index) => 10 ** (index - 12));
  const sampleThetas = [
    0,
    ...edge,
    ...Array.from({ length: gridSize + 1 }, (_, index) => index / gridSize),
    ...edge.map((value) => 1 - value),
    1,
  ].sort((left, right) => left - right).filter((value, index, values) => (
    index === 0 || value - values[index - 1] > 1e-14
  ));
  const samples = sampleThetas.map(evaluate);
  const brackets = [];
  for (let index = 0; index < samples.length - 1; index += 1) {
    if (samples[index].residual === 0 ||
        samples[index].residual * samples[index + 1].residual < 0) {
      brackets.push([samples[index], samples[index + 1]]);
    }
  }
  if (samples.at(-1).residual === 0) brackets.push([samples.at(-1), samples.at(-1)]);
  const fixedPoints = brackets.map(([leftStart, rightStart]) => {
    let left = leftStart;
    let right = rightStart;
    for (let iteration = 0; iteration < 60 && right.theta - left.theta > rootTolerance;
      iteration += 1) {
      const middle = evaluate((left.theta + right.theta) / 2);
      if (left.residual * middle.residual <= 0) right = middle;
      else left = middle;
    }
    const root = evaluate((left.theta + right.theta) / 2);
    const fullState = { theta: root.theta, a: root.state.a, b: root.state.b };
    const jacobian = meanFieldJacobian(fullState, params);
    const eigenvalues = eigenvalues3(jacobian);
    const derivativeStep = Math.min(1e-5, Math.max(1e-8,
      Math.min(root.theta, 1 - root.theta) / 2));
    const lowerResponse = evaluate(Math.max(lowerBound, root.theta - derivativeStep));
    const upperResponse = evaluate(Math.min(upperBound, root.theta + derivativeStep));
    const reducedMultiplier = (upperResponse.response - lowerResponse.response) /
      (upperResponse.theta - lowerResponse.theta);
    return {
      theta: root.theta,
      a: root.state.a,
      b: root.state.b,
      evidenceMean: mean(root.state),
      concentration: summary(root.state).concentration,
      residual: root.residual,
      reducedMultiplier,
      jacobian,
      eigenvalues,
      spectralRadius: eigenvalues[0].modulus,
      stable: eigenvalues[0].modulus < 1,
      approximationThirdMomentError: root.approximationThirdMomentError,
      approximationVarianceClampApplied: root.approximationVarianceClampApplied,
      approximationVarianceToBernoulliRatioMax:
        root.approximationVarianceToBernoulliRatioMax,
    };
  });
  return fixedPoints.filter((point, index, points) => (
    index === 0 || Math.abs(point.theta - points[index - 1].theta) > rootTolerance
  ));
}

function sampleOutcome(probabilities, random) {
  let draw = random();
  for (let index = 0; index < probabilities.candidates.length; index += 1) {
    draw -= probabilities.candidates[index];
    if (draw <= 0) return index;
  }
  return 'outside';
}

function opportunityCount(schedule, step) {
  const value = typeof schedule === 'function' ? schedule(step) : schedule;
  if (!Number.isInteger(value) || value < 0) {
    throw new RangeError(`opportunities at step ${step} must be a non-negative integer, got ${value}`);
  }
  return value;
}

function meanOf(values) {
  return values.reduce((total, value) => total + value, 0) / values.length;
}

function populationVariance(values) {
  const center = meanOf(values);
  return values.reduce((total, value) => total + ((value - center) ** 2), 0) /
    values.length;
}

function populationRate(speakers) {
  return speakers.reduce((total, speaker) => total + Number(speaker.included), 0) /
    speakers.length;
}

function setFinitePopulationInclusionRate(speakers, rate, random) {
  requireProbability(rate, 'inclusion rate');
  const indices = Array.from({ length: speakers.length }, (_, index) => index);
  for (let index = indices.length - 1; index > 0; index -= 1) {
    const other = Math.floor(random() * (index + 1));
    [indices[index], indices[other]] = [indices[other], indices[index]];
  }
  const includedCount = Math.round(rate * speakers.length);
  indices.forEach((speakerIndex, rank) => {
    speakers[speakerIndex].included = rank < includedCount;
  });
}

function validateShocks(shocks, steps) {
  if (!Array.isArray(shocks)) throw new TypeError('shocks must be an array');
  const byStep = new Map();
  shocks.forEach((shock, index) => {
    if (!Number.isInteger(shock?.step) || shock.step < 1 || shock.step > steps) {
      throw new RangeError(`shocks[${index}].step must be in [1, ${steps}]`);
    }
    requireProbability(shock.inclusionRate, `shocks[${index}].inclusionRate`);
    if (byStep.has(shock.step)) {
      throw new RangeError(`only one inclusion shock is allowed at step ${shock.step}`);
    }
    byStep.set(shock.step, shock.inclusionRate);
  });
  return byStep;
}

function validateEvidenceShocks(shocks, steps) {
  if (!Array.isArray(shocks)) throw new TypeError('evidenceShocks must be an array');
  const byStep = new Map();
  shocks.forEach((shock, index) => {
    if (!Number.isInteger(shock?.step) || shock.step < 1 || shock.step > steps) {
      throw new RangeError(`evidenceShocks[${index}].step must be in [1, ${steps}]`);
    }
    requireProbability(shock.evidenceRate, `evidenceShocks[${index}].evidenceRate`);
    requireNonnegative(shock.evidenceStrength,
      `evidenceShocks[${index}].evidenceStrength`);
    if (byStep.has(shock.step)) {
      throw new RangeError(`only one evidence shock is allowed at step ${shock.step}`);
    }
    byStep.set(shock.step, shock);
  });
  return byStep;
}

function summarizeSpeakers(speakers, response) {
  const summaries = speakers.map((speaker) => summary(speaker.evidence));
  const means = summaries.map((item) => item.mean);
  const concentrations = summaries.map((item) => item.concentration);
  const adoptionProbabilities = speakers.map((speaker) => (
    adoptionProbability(speaker.evidence, response)
  ));
  return {
    theta: populationRate(speakers),
    evidenceMean: meanOf(means),
    evidenceMeanVariance: populationVariance(means),
    concentrationMean: meanOf(concentrations),
    adoptionProbabilityMean: meanOf(adoptionProbabilities),
  };
}

/**
 * Simulate one focal target in a two-candidate niche.
 *
 * Candidate 0 is available exactly when the producing speaker includes the
 * target node. Candidate 1 is an always-available competitor. The outside
 * option is always available. Each community event is observed independently
 * by each learner with `observationProbability`, allowing histories to diverge
 * without imposing a particular network topology.
 *
 * Majority repair is optional and explicit. When enabled, a minority target
 * production can supply error evidence against the target, while a competitor
 * production in a target-majority population can supply positive evidence for
 * the repaired-to target. This is an intervention convention for stress tests,
 * not a fitted repair likelihood.
 */
export function simulateClosedLoop(params = {}, steps = 320, seed = 1) {
  const {
    speakerCount = 80,
    initialInclusionRate = 0.5,
    initialEvidenceStrength = 0,
    initialEvidenceRate = initialInclusionRate,
    initialEvidenceState = null,
    priorA = 1,
    priorB = 1,
    priorMeanSpread = 0,
    targetUtility = 0,
    competitorUtility = 0,
    outsideUtility = -4,
    opportunitiesPerStep = 12,
    observationProbability = 0.6,
    deltaM = 0.96,
    targetEvidenceWeight = 1,
    omissionAttribution = 1,
    recoverability = 1,
    inclusionUpdateRate = 0.08,
    adoptionFamily = 'mean',
    adoptionThreshold = 0.5,
    adoptionSlope = 8,
    majorityRepairProbability = 0,
    repairEvidence = 1,
    shocks = [],
    evidenceShocks = [],
  } = params;

  if (!Number.isInteger(speakerCount) || speakerCount < 2) {
    throw new RangeError(`speakerCount must be an integer of at least 2, got ${speakerCount}`);
  }
  if (!Number.isInteger(steps) || steps < 0) {
    throw new RangeError(`steps must be a non-negative integer, got ${steps}`);
  }
  requireProbability(initialInclusionRate, 'initialInclusionRate');
  requireNonnegative(initialEvidenceStrength, 'initialEvidenceStrength');
  requireProbability(initialEvidenceRate, 'initialEvidenceRate');
  if (initialEvidenceState !== null) {
    if (!(initialEvidenceState?.a > 0) || !(initialEvidenceState?.b > 0)) {
      throw new RangeError('initialEvidenceState must supply positive a and b');
    }
    if (priorMeanSpread !== 0) {
      throw new RangeError('initialEvidenceState cannot be combined with priorMeanSpread');
    }
  }
  requireProbability(observationProbability, 'observationProbability');
  requireProbability(recoverability, 'recoverability');
  requireProbability(omissionAttribution, 'omissionAttribution');
  requireProbability(inclusionUpdateRate, 'inclusionUpdateRate');
  requireProbability(majorityRepairProbability, 'majorityRepairProbability');
  requireProbability(repairEvidence, 'repairEvidence');
  requireNonnegative(targetEvidenceWeight, 'targetEvidenceWeight');
  requireFinite(targetUtility, 'targetUtility');
  requireFinite(competitorUtility, 'competitorUtility');
  requireFinite(outsideUtility, 'outsideUtility');
  if (!(priorA > 0) || !(priorB > 0)) {
    throw new RangeError(`Beta prior parameters must be positive, got ${priorA}, ${priorB}`);
  }
  requireNonnegative(priorMeanSpread, 'priorMeanSpread');
  const priorConcentration = priorA + priorB;
  const basePriorMean = priorA / priorConcentration;
  if (priorMeanSpread >= Math.min(basePriorMean, 1 - basePriorMean)) {
    throw new RangeError('priorMeanSpread must keep every speaker prior strictly inside (0, 1)');
  }
  const response = {
    family: adoptionFamily,
    threshold: adoptionThreshold,
    slope: adoptionSlope,
  };
  // Validate the response even when steps is zero.
  adoptionProbability(makeEvidenceState({ priorA, priorB }), response);
  const shocksByStep = validateShocks(shocks, steps);
  const evidenceShocksByStep = validateEvidenceShocks(evidenceShocks, steps);
  const random = mulberry32(seed);
  const speakers = Array.from({ length: speakerCount }, () => {
    const speakerPriorMean = basePriorMean +
      priorMeanSpread * ((2 * random()) - 1);
    return {
      included: false,
      evidence: initialEvidenceState
        ? makeEvidenceState({
          priorA: priorConcentration * speakerPriorMean,
          priorB: priorConcentration * (1 - speakerPriorMean),
          a: initialEvidenceState.a,
          b: initialEvidenceState.b,
        })
        : makeEvidenceState({
          priorA: priorConcentration * speakerPriorMean,
          priorB: priorConcentration * (1 - speakerPriorMean),
          positiveEvidence: initialEvidenceStrength * initialEvidenceRate,
          negativeEvidence: initialEvidenceStrength * (1 - initialEvidenceRate),
        }),
    };
  });
  setFinitePopulationInclusionRate(speakers, initialInclusionRate, random);

  const rows = [{
    step: 0,
    opportunities: 0,
    targetTokens: 0,
    competitorTokens: 0,
    outsideChoices: 0,
    repairsForTarget: 0,
    repairsAgainstTarget: 0,
    shockInclusionRate: null,
    shockEvidenceRate: null,
    shockEvidenceStrength: null,
    approximationThirdMomentErrorMean: 0,
    approximationThirdMomentErrorMax: 0,
    approximationVarianceClampFraction: 0,
    approximationVarianceToBernoulliRatioMax: 0,
    ...summarizeSpeakers(speakers, response),
  }];

  for (let step = 1; step <= steps; step += 1) {
    let shockInclusionRate = null;
    if (shocksByStep.has(step)) {
      shockInclusionRate = shocksByStep.get(step);
      setFinitePopulationInclusionRate(speakers, shockInclusionRate, random);
    }
    const thetaBeforeEvidence = populationRate(speakers);
    const opportunities = opportunityCount(opportunitiesPerStep, step);
    const events = [];
    let targetTokens = 0;
    let competitorTokens = 0;
    let outsideChoices = 0;
    let repairsForTarget = 0;
    let repairsAgainstTarget = 0;

    for (let occasion = 0; occasion < opportunities; occasion += 1) {
      const producer = speakers[Math.floor(random() * speakers.length)];
      const availability = [producer.included, true];
      const probabilities = gatedChoiceProbabilities({
        utilities: [targetUtility, competitorUtility],
        availability,
        outsideUtility,
      });
      const outcome = sampleOutcome(probabilities, random);
      let targetCount = 0;
      const omissionContrasts = [];
      if (outcome === 0) {
        targetTokens += 1;
        targetCount = 1;
        if (thetaBeforeEvidence < 0.5 && random() < majorityRepairProbability) {
          repairsAgainstTarget += 1;
          omissionContrasts.push(repairEvidence);
        }
      } else {
        if (outcome === 1) competitorTokens += 1;
        else outsideChoices += 1;
        const omission = omissionEvidenceFromChoice({
          utilities: [targetUtility, competitorUtility],
          availability,
          targetIndex: 0,
          observedOutcome: outcome,
          outsideUtility,
          recoverability,
        });
        omissionContrasts.push(
          omissionAttribution * omission.availabilityContrast,
        );
        if (outcome === 1 && thetaBeforeEvidence > 0.5 &&
            random() < majorityRepairProbability) {
          repairsForTarget += 1;
          targetCount += repairEvidence;
        }
      }
      events.push({ targetCount, omissionContrasts });
    }

    const evidenceUpdates = speakers.map((speaker) => {
      let targetCount = 0;
      const omissionContrasts = [];
      events.forEach((event) => {
        if (random() < observationProbability) {
          targetCount += event.targetCount;
          omissionContrasts.push(...event.omissionContrasts);
        }
      });
      return availabilityPosteriorUpdate(
        speaker.evidence,
        { targetCount, omissionContrasts },
        { deltaM, targetEvidenceWeight },
      );
    });
    const evidenceShock = evidenceShocksByStep.get(step) ?? null;
    const nextEvidence = evidenceUpdates.map((update, index) => {
      if (!evidenceShock) return update.state;
      const prior = speakers[index].evidence;
      return makeEvidenceState({
        priorA: prior.priorA,
        priorB: prior.priorB,
        positiveEvidence: evidenceShock.evidenceStrength * evidenceShock.evidenceRate,
        negativeEvidence: evidenceShock.evidenceStrength * (1 - evidenceShock.evidenceRate),
      });
    });
    const nextInclusions = speakers.map((speaker, index) => {
      const h = adoptionProbability(nextEvidence[index], response);
      const probability = (1 - inclusionUpdateRate) * Number(speaker.included) +
        inclusionUpdateRate * h;
      requireProbability(probability, 'inclusion transition probability');
      return random() < probability;
    });
    speakers.forEach((speaker, index) => {
      speaker.evidence = nextEvidence[index];
      speaker.included = nextInclusions[index];
    });
    rows.push({
      step,
      opportunities,
      targetTokens,
      competitorTokens,
      outsideChoices,
      repairsForTarget,
      repairsAgainstTarget,
      shockInclusionRate,
      shockEvidenceRate: evidenceShock?.evidenceRate ?? null,
      shockEvidenceStrength: evidenceShock?.evidenceStrength ?? null,
      approximationThirdMomentErrorMean: meanOf(evidenceUpdates.map(
        (update) => update.approximation.absoluteThirdMomentError,
      )),
      approximationThirdMomentErrorMax: Math.max(...evidenceUpdates.map(
        (update) => update.approximation.absoluteThirdMomentError,
      )),
      approximationVarianceClampFraction: evidenceUpdates.filter(
        (update) => update.approximation.varianceClampApplied,
      ).length / evidenceUpdates.length,
      approximationVarianceToBernoulliRatioMax: Math.max(...evidenceUpdates.map(
        (update) => update.approximation.varianceToBernoulliRatio,
      )),
      ...summarizeSpeakers(speakers, response),
    });
  }

  return {
    rows,
    finalSpeakers: speakers.map((speaker) => ({
      included: speaker.included,
      evidence: { ...speaker.evidence },
    })),
  };
}

/** Mean population rate over the final fraction of a run. */
export function tailMeanTheta(run, tailFraction = 0.25) {
  requireProbability(tailFraction, 'tailFraction');
  if (tailFraction === 0) throw new RangeError('tailFraction must be positive');
  const rows = run.rows;
  const tailLength = Math.max(1, Math.ceil(rows.length * tailFraction));
  return meanOf(rows.slice(-tailLength).map((row) => row.theta));
}

/**
 * Operational, preregisterable endpoint-concentration diagnostic. It is not a
 * general statistical test for multimodality. Both endpoint basins have to be
 * occupied, most runs have to lie near an endpoint, and few may remain central.
 */
export function endpointConcentrationDiagnostic(thetaValues, criteria = {}) {
  if (!Array.isArray(thetaValues) || thetaValues.length < 2) {
    throw new RangeError('thetaValues must contain at least two replicate summaries');
  }
  thetaValues.forEach((value, index) => requireProbability(value, `thetaValues[${index}]`));
  const {
    lowerCut = 0.2,
    upperCut = 0.8,
    centralLower = 0.4,
    centralUpper = 0.6,
    minimumEndpointFraction = 0.7,
    maximumCentralFraction = 0.2,
    minimumEachBasinFraction = 0.15,
  } = criteria;
  [lowerCut, upperCut, centralLower, centralUpper, minimumEndpointFraction,
    maximumCentralFraction, minimumEachBasinFraction].forEach((value, index) => (
    requireProbability(value, `criteria[${index}]`)
  ));
  if (!(lowerCut < centralLower && centralLower < centralUpper && centralUpper < upperCut)) {
    throw new RangeError('diagnostic cuts must satisfy lower < centralLower < centralUpper < upper');
  }
  const fraction = (predicate) => thetaValues.filter(predicate).length / thetaValues.length;
  const lowerFraction = fraction((value) => value <= lowerCut);
  const upperFraction = fraction((value) => value >= upperCut);
  const centralFraction = fraction((value) => value >= centralLower && value <= centralUpper);
  const endpointFraction = lowerFraction + upperFraction;
  return {
    replicateCount: thetaValues.length,
    meanTailTheta: meanOf(thetaValues),
    varianceTailTheta: populationVariance(thetaValues),
    lowerFraction,
    upperFraction,
    endpointFraction,
    centralFraction,
    bothBasinsOccupied: lowerFraction >= minimumEachBasinFraction &&
      upperFraction >= minimumEachBasinFraction,
    endpointConcentrated: endpointFraction >= minimumEndpointFraction &&
      centralFraction <= maximumCentralFraction &&
      lowerFraction >= minimumEachBasinFraction &&
      upperFraction >= minimumEachBasinFraction,
    criteria: {
      lowerCut,
      upperCut,
      centralLower,
      centralUpper,
      minimumEndpointFraction,
      maximumCentralFraction,
      minimumEachBasinFraction,
    },
  };
}

/**
 * Finite-horizon basin diagnostic. Runs deliberately initialized low and high
 * have to remain in their respective endpoint regions. This tests attraction
 * from both sides without pretending that a short collection of trajectories
 * is a draw from the Markov chain's stationary distribution.
 */
export function basinSeparationDiagnostic(lowInitialTheta, highInitialTheta, criteria = {}) {
  if (!Array.isArray(lowInitialTheta) || !Array.isArray(highInitialTheta) ||
      lowInitialTheta.length < 2 || highInitialTheta.length < 2) {
    throw new RangeError('both basin samples must contain at least two replicate summaries');
  }
  [...lowInitialTheta, ...highInitialTheta].forEach((value, index) => (
    requireProbability(value, `basin theta[${index}]`)
  ));
  const {
    lowerCut = 0.2,
    upperCut = 0.8,
    minimumRetentionFraction = 0.8,
  } = criteria;
  [lowerCut, upperCut, minimumRetentionFraction].forEach((value, index) => (
    requireProbability(value, `basin criteria[${index}]`)
  ));
  if (!(lowerCut < upperCut)) throw new RangeError('lowerCut must be below upperCut');
  const lowRetentionFraction = lowInitialTheta.filter((value) => value <= lowerCut).length /
    lowInitialTheta.length;
  const highRetentionFraction = highInitialTheta.filter((value) => value >= upperCut).length /
    highInitialTheta.length;
  return {
    lowReplicateCount: lowInitialTheta.length,
    highReplicateCount: highInitialTheta.length,
    meanLowInitialTailTheta: meanOf(lowInitialTheta),
    meanHighInitialTailTheta: meanOf(highInitialTheta),
    lowRetentionFraction,
    highRetentionFraction,
    basinSeparated: lowRetentionFraction >= minimumRetentionFraction &&
      highRetentionFraction >= minimumRetentionFraction,
    criteria: { lowerCut, upperCut, minimumRetentionFraction },
  };
}
