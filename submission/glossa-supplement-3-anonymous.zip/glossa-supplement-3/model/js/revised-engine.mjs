// revised-engine.mjs -- v2 quantitative core for the current OVMG manuscript.
//
// This module is deliberately separate from engine.js. The browser lab and its
// fixtures implement the 2026-07-09 prototype; this is the reference core for
// the revised Sections 3--4. It implements four commitments:
//
//   1. Discount evidence, not the baseline prior.
//   2. Derive target and omission evidence from one normalized choice model.
//   3. Update the availability posterior with its exact finite-batch mixture.
//   4. Moment-match that mixture back to a Beta state for bounded filtering.
//
// It is an executable model contract, not a fitted empirical model. In
// particular, its independent speaker inclusion draws are a default that a
// latent-lect model can replace when assembly-level co-licensing is material.

function requireFinite(value, name) {
  if (!Number.isFinite(value)) {
    throw new TypeError(`${name} must be finite, got ${value}`);
  }
}

function requireNonnegative(value, name) {
  requireFinite(value, name);
  if (value < 0) throw new RangeError(`${name} must be non-negative, got ${value}`);
}

function requireProbability(value, name) {
  requireFinite(value, name);
  if (value < 0 || value > 1) {
    throw new RangeError(`${name} must be in [0, 1], got ${value}`);
  }
}

/**
 * Beta approximation for one construction--situation pair. `a` and `b` are
 * stored directly because moment matching need not leave non-negative
 * pseudo-count offsets from each prior parameter. The fixed baseline prior is
 * retained separately so a quiet node returns to it.
 */
export function makeEvidenceState({
  priorA = 1,
  priorB = 1,
  positiveEvidence = 0,
  negativeEvidence = 0,
  a = priorA + positiveEvidence,
  b = priorB + negativeEvidence,
} = {}) {
  if (!(priorA > 0) || !(priorB > 0)) {
    throw new RangeError(`Beta prior parameters must be positive, got ${priorA}, ${priorB}`);
  }
  requireNonnegative(positiveEvidence, 'positiveEvidence');
  requireNonnegative(negativeEvidence, 'negativeEvidence');
  if (!(a > 0) || !(b > 0)) {
    throw new RangeError(`Beta state parameters must be positive, got ${a}, ${b}`);
  }
  return { priorA, priorB, a, b };
}

/** Current parameters of the moment-matched Beta approximation. */
export function posteriorParameters(state) {
  if (!(state?.a > 0) || !(state?.b > 0)) {
    throw new RangeError(`invalid Beta state parameters ${state?.a}, ${state?.b}`);
  }
  return { a: state.a, b: state.b };
}

/**
 * Baseline-preserving discount. Discounting is applied before the current
 * batch likelihood and exactly once per update.
 */
export function discountEvidenceState(state, deltaM = 1) {
  if (!(deltaM > 0) || deltaM > 1) {
    throw new RangeError(`deltaM must be in (0, 1], got ${deltaM}`);
  }
  const { a, b } = posteriorParameters(state);
  return makeEvidenceState({
    priorA: state.priorA,
    priorB: state.priorB,
    a: state.priorA + deltaM * (a - state.priorA),
    b: state.priorB + deltaM * (b - state.priorB),
  });
}

/**
 * Compatibility helper for explicitly generalized-score experiments. The
 * current-paper simulators do not call this function: adding an omission LLR
 * to `b` is not conjugate Bayes for the declared choice likelihood.
 */
export function updateEvidence(state, evidence = {}, params = {}) {
  const { positive = 0, negative = 0 } = evidence;
  const { deltaM = 1, lambdaPos = 1, lambdaNeg = 1 } = params;
  requireNonnegative(positive, 'positive');
  requireNonnegative(negative, 'negative');
  requireNonnegative(lambdaPos, 'lambdaPos');
  requireNonnegative(lambdaNeg, 'lambdaNeg');
  const discounted = discountEvidenceState(state, deltaM);
  return makeEvidenceState({
    priorA: state.priorA,
    priorB: state.priorB,
    a: discounted.a + lambdaPos * positive,
    b: discounted.b + lambdaNeg * negative,
  });
}

/** Posterior mean C_t for a single pivotal node. */
export function mean(state) {
  const { a, b } = posteriorParameters(state);
  return a / (a + b);
}

/** Posterior concentration nu_t for a single pivotal node. */
export function concentration(state) {
  const { a, b } = posteriorParameters(state);
  return a + b;
}

/** Var(theta | D): epistemic uncertainty about the population licensing rate. */
export function epistemicVariance(state) {
  const m = mean(state);
  return (m * (1 - m)) / (concentration(state) + 1);
}

/** E[theta(1-theta) | D]: predictive between-speaker heterogeneity. */
export function heterogeneityVariance(state) {
  const m = mean(state);
  const nu = concentration(state);
  return (m * (1 - m) * nu) / (nu + 1);
}

/** Convenience summary for logging and test assertions. */
export function summary(state) {
  const { a, b } = posteriorParameters(state);
  return {
    a,
    b,
    mean: mean(state),
    concentration: concentration(state),
    epistemicVariance: epistemicVariance(state),
    heterogeneityVariance: heterogeneityVariance(state),
  };
}

// Numerics for the decision-confidence read-out. This is a local copy rather
// than an import from the frozen v1 engine: v2 must remain self-contained.
const LANCZOS_G = 7;
const LANCZOS_C = [
  0.99999999999980993, 676.5203681218851, -1259.1392167224028,
  771.32342877765313, -176.61502916214059, 12.507343278686905,
  -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7,
];

function logGamma(value) {
  if (value < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * value)) - logGamma(1 - value);
  }
  const shifted = value - 1;
  let sum = LANCZOS_C[0];
  for (let index = 1; index < LANCZOS_C.length; index += 1) {
    sum += LANCZOS_C[index] / (shifted + index);
  }
  const t = shifted + LANCZOS_G + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (shifted + 0.5) * Math.log(t) - t + Math.log(sum);
}

function logBeta(a, b) {
  return logGamma(a) + logGamma(b) - logGamma(a + b);
}

function betaRawMoment(a, b, order) {
  let numerator = 1;
  let denominator = 1;
  for (let index = 0; index < order; index += 1) {
    numerator *= a + index;
    denominator *= a + b + index;
  }
  return numerator / denominator;
}

function betaFromMoments(firstMoment, variance) {
  requireProbability(firstMoment, 'posterior first moment');
  requireFinite(variance, 'posterior variance');
  if (!(firstMoment > 0 && firstMoment < 1) || !(variance > 0)) {
    throw new RangeError(`cannot moment-match mean ${firstMoment}, variance ${variance}`);
  }
  const bernoulliVariance = firstMoment * (1 - firstMoment);
  const safeVariance = Math.min(variance, bernoulliVariance * (1 - 1e-14));
  const varianceClampApplied = safeVariance !== variance;
  const concentration = (bernoulliVariance / safeVariance) - 1;
  if (!(concentration > 0) || !Number.isFinite(concentration)) {
    throw new RangeError(`invalid moment-matched concentration ${concentration}`);
  }
  return {
    a: firstMoment * concentration,
    b: (1 - firstMoment) * concentration,
    varianceClampApplied,
    varianceToBernoulliRatio: variance / bernoulliVariance,
  };
}

/**
 * Exact finite-batch posterior moments under the declared availability model.
 *
 * A target token contributes a factor `theta`. A non-target event with
 * contrast `d = 1 - P(y|available)/P(y|unavailable)` contributes
 * `1 - d * theta`. The product of `m` such affine factors turns a Beta state
 * into a mixture of at most `m + 1` Betas. Existing evidence is discounted
 * before this batch is applied.
 *
 * `targetEvidenceWeight` is a power-likelihood option retained for explicit
 * sensitivity work. It is one in the current-paper simulations.
 */
export function availabilityPosteriorUpdate(state, evidence = {}, params = {}) {
  const { targetCount = 0, omissionContrasts = [] } = evidence;
  const { deltaM = 1, targetEvidenceWeight = 1 } = params;
  requireNonnegative(targetCount, 'targetCount');
  requireNonnegative(targetEvidenceWeight, 'targetEvidenceWeight');
  if (!Array.isArray(omissionContrasts)) {
    throw new TypeError('omissionContrasts must be an array');
  }
  omissionContrasts.forEach((contrast, index) => (
    requireProbability(contrast, `omissionContrasts[${index}]`)
  ));

  const discounted = discountEvidenceState(state, deltaM);
  const baseA = discounted.a + targetEvidenceWeight * targetCount;
  const baseB = discounted.b;
  const omissionCount = omissionContrasts.length;

  let coefficients = [1];
  omissionContrasts.forEach((contrast) => {
    const next = Array(coefficients.length + 1).fill(0);
    coefficients.forEach((coefficient, index) => {
      next[index] += coefficient;
      next[index + 1] += coefficient * (1 - contrast);
    });
    const scale = Math.max(...next);
    coefficients = scale > 0 ? next.map((value) => value / scale) : next;
  });

  const logMasses = coefficients.map((coefficient, availableBranches) => {
    if (coefficient === 0) return -Infinity;
    return Math.log(coefficient) +
      logBeta(baseA + availableBranches, baseB + omissionCount - availableBranches);
  });
  const maxLogMass = Math.max(...logMasses);
  const unnormalizedWeights = logMasses.map((value) => (
    value === -Infinity ? 0 : Math.exp(value - maxLogMass)
  ));
  const weightTotal = unnormalizedWeights.reduce((total, value) => total + value, 0);
  const weights = unnormalizedWeights.map((value) => value / weightTotal);

  const components = weights.map((weight, availableBranches) => {
    const a = baseA + availableBranches;
    const b = baseB + omissionCount - availableBranches;
    return { a, b, weight };
  });
  const firstMoment = components.reduce((total, component) => (
    total + component.weight * betaRawMoment(component.a, component.b, 1)
  ), 0);
  const secondMoment = components.reduce((total, component) => (
    total + component.weight * betaRawMoment(component.a, component.b, 2)
  ), 0);
  const thirdMoment = components.reduce((total, component) => (
    total + component.weight * betaRawMoment(component.a, component.b, 3)
  ), 0);
  const variance = secondMoment - (firstMoment ** 2);
  const matched = betaFromMoments(firstMoment, variance);
  const matchedThirdMoment = betaRawMoment(matched.a, matched.b, 3);
  const nextState = makeEvidenceState({
    priorA: state.priorA,
    priorB: state.priorB,
    a: matched.a,
    b: matched.b,
  });
  return {
    state: nextState,
    exactMoments: { mean: firstMoment, variance, secondMoment, thirdMoment },
    matchedMoments: {
      mean: mean(nextState),
      variance: epistemicVariance(nextState),
      thirdMoment: matchedThirdMoment,
    },
    approximation: {
      componentCount: components.filter((component) => component.weight > 0).length,
      thirdMomentError: matchedThirdMoment - thirdMoment,
      absoluteThirdMomentError: Math.abs(matchedThirdMoment - thirdMoment),
      varianceClampApplied: matched.varianceClampApplied,
      varianceToBernoulliRatio: matched.varianceToBernoulliRatio,
    },
    components,
  };
}

/** Moment-matched Beta state after one discounted finite batch. */
export function updateAvailabilityPosterior(state, evidence = {}, params = {}) {
  return availabilityPosteriorUpdate(state, evidence, params).state;
}

let gaussLegendreRule = null;

function getGaussLegendreRule(order = 128) {
  if (gaussLegendreRule?.order === order) return gaussLegendreRule;
  const nodes = Array(order);
  const weights = Array(order);
  const half = Math.ceil(order / 2);
  for (let index = 0; index < half; index += 1) {
    let root = Math.cos(Math.PI * (index + 0.75) / (order + 0.5));
    let derivative = 0;
    for (let iteration = 0; iteration < 30; iteration += 1) {
      let previous = 1;
      let current = root;
      for (let degree = 2; degree <= order; degree += 1) {
        const next = ((2 * degree - 1) * root * current -
          (degree - 1) * previous) / degree;
        previous = current;
        current = next;
      }
      derivative = order * (root * current - previous) / ((root ** 2) - 1);
      const nextRoot = root - current / derivative;
      if (Math.abs(nextRoot - root) < 2e-15) {
        root = nextRoot;
        break;
      }
      root = nextRoot;
    }
    const weight = 2 / ((1 - (root ** 2)) * (derivative ** 2));
    nodes[index] = -root;
    nodes[order - 1 - index] = root;
    weights[index] = weight;
    weights[order - 1 - index] = weight;
  }
  gaussLegendreRule = { order, nodes, weights };
  return gaussLegendreRule;
}

function logLogistic(value) {
  return value >= 0
    ? -Math.log1p(Math.exp(-value))
    : value - Math.log1p(Math.exp(value));
}

function logOneMinusLogistic(value) {
  return value >= 0
    ? -value - Math.log1p(Math.exp(-value))
    : -Math.log1p(Math.exp(value));
}

function logQuadratureMoment({ a, b, targetPower, omissionContrast, omissionPower, order }) {
  const rule = getGaussLegendreRule();
  const leftShape = a + targetPower + order;
  const derivativeAtTheta = (theta) => (
    leftShape * (1 - theta) - b * theta -
    omissionPower * omissionContrast * theta * (1 - theta) /
      (1 - omissionContrast * theta)
  );
  let lowerTheta = 1e-15;
  let upperTheta = 1 - 1e-15;
  for (let iteration = 0; iteration < 100; iteration += 1) {
    const middleTheta = (lowerTheta + upperTheta) / 2;
    if (derivativeAtTheta(middleTheta) > 0) lowerTheta = middleTheta;
    else upperTheta = middleTheta;
  }
  const modeTheta = (lowerTheta + upperTheta) / 2;
  const modeLogit = Math.log(modeTheta) - Math.log1p(-modeTheta);
  const finiteDifference = Math.max(1e-8, 1e-5 * Math.min(modeTheta, 1 - modeTheta));
  const lowerDerivative = derivativeAtTheta(Math.max(1e-15, modeTheta - finiteDifference));
  const upperDerivative = derivativeAtTheta(Math.min(1 - 1e-15, modeTheta + finiteDifference));
  const derivativeSlope = (upperDerivative - lowerDerivative) / (2 * finiteDifference);
  const curvature = Math.max(1e-6, -modeTheta * (1 - modeTheta) * derivativeSlope);
  const localScale = 1 / Math.sqrt(curvature);
  const lowerX = modeLogit - Math.max(12 * localScale, 24 / leftShape);
  const upperX = modeLogit + Math.max(12 * localScale, 24 / b);
  const centerX = (lowerX + upperX) / 2;
  const halfWidth = (upperX - lowerX) / 2;
  const logTerms = rule.nodes.map((node, index) => {
    const x = centerX + halfWidth * node;
    const logTheta = logLogistic(x);
    const logOneMinusTheta = logOneMinusLogistic(x);
    const theta = Math.exp(logTheta);
    const logAffine = omissionContrast === 0
      ? 0
      : Math.log1p(-omissionContrast * theta);
    return Math.log(rule.weights[index] * halfWidth) +
      (a + targetPower + order) * logTheta +
      b * logOneMinusTheta +
      omissionPower * logAffine;
  });
  const maxLogTerm = Math.max(...logTerms);
  return maxLogTerm + Math.log(logTerms.reduce((total, value) => (
    total + Math.exp(value - maxLogTerm)
  ), 0));
}

/**
 * Expected-batch closure used only by the deterministic mean-field diagnostic.
 * It permits fractional target and omission powers, evaluates the resulting
 * one-dimensional posterior by quadrature, and moment-matches it to Beta.
 * The finite-event simulators use `availabilityPosteriorUpdate` instead.
 */
export function availabilityPowerPosteriorUpdate(state, evidence = {}, params = {}) {
  const {
    targetPower = 0,
    omissionContrast = 0,
    omissionPower = 0,
  } = evidence;
  const { deltaM = 1 } = params;
  requireNonnegative(targetPower, 'targetPower');
  requireProbability(omissionContrast, 'omissionContrast');
  requireNonnegative(omissionPower, 'omissionPower');
  const discounted = discountEvidenceState(state, deltaM);
  const exactBeta = omissionPower === 0 || omissionContrast === 0 || omissionContrast === 1;
  if (exactBeta) {
    const a = discounted.a + targetPower;
    const b = discounted.b + (omissionContrast === 1 ? omissionPower : 0);
    const nextState = makeEvidenceState({
      priorA: state.priorA,
      priorB: state.priorB,
      a,
      b,
    });
    const exactMean = betaRawMoment(a, b, 1);
    const exactVariance = epistemicVariance(nextState);
    return {
      state: nextState,
      exactMoments: {
        mean: exactMean,
        variance: exactVariance,
        secondMoment: betaRawMoment(a, b, 2),
        thirdMoment: betaRawMoment(a, b, 3),
      },
      approximation: {
        absoluteThirdMomentError: 0,
        varianceClampApplied: false,
        varianceToBernoulliRatio: exactVariance / (exactMean * (1 - exactMean)),
      },
    };
  }
  const logMoments = [0, 1, 2, 3].map((order) => logQuadratureMoment({
    a: discounted.a,
    b: discounted.b,
    targetPower,
    omissionContrast,
    omissionPower,
    order,
  }));
  const rawMoments = logMoments.map((value) => Math.exp(value - logMoments[0]));
  const firstMoment = rawMoments[1];
  const secondMoment = rawMoments[2];
  const thirdMoment = rawMoments[3];
  const variance = secondMoment - (firstMoment ** 2);
  const matched = betaFromMoments(firstMoment, variance);
  const nextState = makeEvidenceState({
    priorA: state.priorA,
    priorB: state.priorB,
    a: matched.a,
    b: matched.b,
  });
  const matchedThirdMoment = betaRawMoment(matched.a, matched.b, 3);
  return {
    state: nextState,
    exactMoments: { mean: firstMoment, variance, secondMoment, thirdMoment },
    approximation: {
      absoluteThirdMomentError: Math.abs(matchedThirdMoment - thirdMoment),
      varianceClampApplied: matched.varianceClampApplied,
      varianceToBernoulliRatio: matched.varianceToBernoulliRatio,
    },
  };
}

function betaContinuedFraction(x, a, b) {
  const maxIterations = 300;
  const epsilon = 3e-15;
  const floor = 1e-300;
  const sum = a + b;
  const aPlusOne = a + 1;
  const aMinusOne = a - 1;
  let c = 1;
  let d = 1 - (sum * x) / aPlusOne;
  if (Math.abs(d) < floor) d = floor;
  d = 1 / d;
  let result = d;
  for (let step = 1; step <= maxIterations; step += 1) {
    const twice = 2 * step;
    let coefficient = (step * (b - step) * x) / ((aMinusOne + twice) * (a + twice));
    d = 1 + coefficient * d;
    if (Math.abs(d) < floor) d = floor;
    c = 1 + coefficient / c;
    if (Math.abs(c) < floor) c = floor;
    d = 1 / d;
    result *= d * c;
    coefficient = (-(a + step) * (sum + step) * x) /
      ((a + twice) * (aPlusOne + twice));
    d = 1 + coefficient * d;
    if (Math.abs(d) < floor) d = floor;
    c = 1 + coefficient / c;
    if (Math.abs(c) < floor) c = floor;
    d = 1 / d;
    const change = d * c;
    result *= change;
    if (Math.abs(change - 1) < epsilon) return result;
  }
  throw new Error('beta continued fraction failed to converge');
}

/** Regularized incomplete Beta CDF at x for Beta(a, b). */
export function betaCdf(x, a, b) {
  requireProbability(x, 'x');
  if (!(a > 0) || !(b > 0)) {
    throw new RangeError(`Beta parameters must be positive, got ${a}, ${b}`);
  }
  if (x === 0) return 0;
  if (x === 1) return 1;
  const logFront = logGamma(a + b) - logGamma(a) - logGamma(b) +
    a * Math.log(x) + b * Math.log(1 - x);
  const front = Math.exp(logFront);
  if (x < (a + 1) / (a + b + 2)) {
    return (front * betaContinuedFraction(x, a, b)) / a;
  }
  return 1 - (front * betaContinuedFraction(1 - x, b, a)) / b;
}

/** Posterior probability that a node's population rate meets a decision threshold. */
export function posteriorProbabilityAtLeast(state, threshold) {
  requireProbability(threshold, 'threshold');
  if (threshold === 0) return 1;
  if (threshold === 1) return 0;
  const { a, b } = posteriorParameters(state);
  return 1 - betaCdf(threshold, a, b);
}

/**
 * Decision confidence Phi_dec: certainty about which side of the membership
 * threshold the population rate lies. The situation-indexed threshold must be
 * supplied explicitly; 0.5 is not a model-wide default. Decision confidence can
 * remain low for a precisely known interior population rate, unlike
 * concentration-based evidence confidence.
 */
export function decisionConfidence(state, threshold) {
  const probabilityAtLeast = posteriorProbabilityAtLeast(state, threshold);
  return Math.max(probabilityAtLeast, 1 - probabilityAtLeast);
}

/**
 * Normalized gated softmax for a speaker's available candidate set. The
 * outside option is always available. `availability[k]` is that speaker's
 * inclusion state for candidate k in the relevant situation.
 */
export function gatedChoiceProbabilities({ utilities, availability, outsideUtility = 0 }) {
  if (!Array.isArray(utilities) || !Array.isArray(availability)) {
    throw new TypeError('utilities and availability must be arrays');
  }
  if (utilities.length !== availability.length || utilities.length === 0) {
    throw new RangeError('utilities and availability must have the same non-zero length');
  }
  utilities.forEach((utility, index) => requireFinite(utility, `utilities[${index}]`));
  availability.forEach((available, index) => {
    if (typeof available !== 'boolean') {
      throw new TypeError(`availability[${index}] must be boolean`);
    }
  });
  requireFinite(outsideUtility, 'outsideUtility');

  const activeUtilities = [outsideUtility];
  for (let index = 0; index < utilities.length; index += 1) {
    if (availability[index]) activeUtilities.push(utilities[index]);
  }
  const maxUtility = Math.max(...activeUtilities);
  const outsideWeight = Math.exp(outsideUtility - maxUtility);
  const weights = utilities.map((utility, index) => (
    availability[index] ? Math.exp(utility - maxUtility) : 0
  ));
  const normalizer = outsideWeight + weights.reduce((total, weight) => total + weight, 0);
  return {
    candidates: weights.map((weight) => weight / normalizer),
    outside: outsideWeight / normalizer,
  };
}

/** Probability of an observable candidate index or the outside option. */
export function outcomeProbability(probabilities, outcome) {
  if (outcome === 'outside') return probabilities.outside;
  if (!Number.isInteger(outcome) || outcome < 0 || outcome >= probabilities.candidates.length) {
    throw new RangeError(`outcome must be a candidate index or 'outside', got ${outcome}`);
  }
  return probabilities.candidates[outcome];
}

/**
 * Log evidence against target availability from a non-target outcome:
 * log P(y | target unavailable) - log P(y | target available).
 */
export function omissionLogLikelihoodRatio({
  probabilityIfAvailable,
  probabilityIfUnavailable,
}) {
  requireProbability(probabilityIfAvailable, 'probabilityIfAvailable');
  requireProbability(probabilityIfUnavailable, 'probabilityIfUnavailable');
  if (probabilityIfAvailable === 0 || probabilityIfUnavailable === 0) {
    throw new RangeError('omission likelihoods must be positive for a finite log ratio');
  }
  return Math.log(probabilityIfUnavailable) - Math.log(probabilityIfAvailable);
}

/**
 * Generic splitter for a hypothesis-dependent observation model. Under the
 * fixed-utility, fixed-other-gates choice model below, a non-target outcome
 * cannot yield the positive branch: adding the target only enlarges the
 * normalizer.
 */
export function routeOmissionEvidence({ logLikelihoodRatio, recoverability = 1 }) {
  requireFinite(logLikelihoodRatio, 'logLikelihoodRatio');
  requireProbability(recoverability, 'recoverability');
  return {
    positive: recoverability * Math.max(-logLikelihoodRatio, 0),
    negative: recoverability * Math.max(logLikelihoodRatio, 0),
  };
}

/**
 * Exact counterfactual quantities for a non-target outcome. The log ratio is
 * an information diagnostic. The affine availability contrast is the quantity
 * used by the posterior update: after dropping a theta-independent constant,
 * the event likelihood is `1 - availabilityContrast * theta`.
 */
export function omissionEvidenceFromChoice({
  utilities,
  availability,
  targetIndex,
  observedOutcome,
  outsideUtility = 0,
  recoverability = 1,
}) {
  if (!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= utilities.length) {
    throw new RangeError(`targetIndex must identify a candidate, got ${targetIndex}`);
  }
  if (observedOutcome === targetIndex) {
    throw new RangeError('target production is direct positive evidence, not an omission');
  }
  const available = availability.slice();
  const unavailable = availability.slice();
  available[targetIndex] = true;
  unavailable[targetIndex] = false;
  const pAvailable = outcomeProbability(
    gatedChoiceProbabilities({ utilities, availability: available, outsideUtility }),
    observedOutcome,
  );
  const pUnavailable = outcomeProbability(
    gatedChoiceProbabilities({ utilities, availability: unavailable, outsideUtility }),
    observedOutcome,
  );
  const logLikelihoodRatio = omissionLogLikelihoodRatio({
    probabilityIfAvailable: pAvailable,
    probabilityIfUnavailable: pUnavailable,
  });
  if (logLikelihoodRatio < -1e-12) {
    throw new Error('fixed-gate omission LLR must be nonnegative');
  }
  const rawAvailabilityContrast = Math.max(
    0,
    Math.min(1, 1 - (pAvailable / pUnavailable)),
  );
  const availabilityContrast = recoverability * rawAvailabilityContrast;
  return {
    probabilityIfAvailable: pAvailable,
    probabilityIfUnavailable: pUnavailable,
    logLikelihoodRatio,
    rawAvailabilityContrast,
    availabilityContrast,
  };
}

function logistic(value) {
  if (value >= 0) {
    const inverse = Math.exp(-value);
    return 1 / (1 + inverse);
  }
  const direct = Math.exp(value);
  return direct / (1 + direct);
}

/**
 * Logistic repair link from the paper's projectible-use equation:
 * sigma(eta0 + eta1 * (1 - G) * r(Delta, footing)). The bounded exponential
 * response is the executable convention for r, not an additional link.
 */
export function repairProbability({
  intercept = 0,
  statusEstimate = 1,
  divergence = 0,
  footing = 1,
  sensitivity = 1,
}) {
  requireFinite(intercept, 'intercept');
  requireProbability(statusEstimate, 'statusEstimate');
  requireNonnegative(divergence, 'divergence');
  requireNonnegative(footing, 'footing');
  requireNonnegative(sensitivity, 'sensitivity');
  const repairResponse = 1 - Math.exp(-divergence * footing);
  return logistic(intercept + sensitivity * (1 - statusEstimate) * repairResponse);
}

/** Expected repair flow, N * P(mis-set) * r(Delta, footing). */
export function repairFlow({ opportunities, misSetProbability, repairResponse }) {
  requireNonnegative(opportunities, 'opportunities');
  requireProbability(misSetProbability, 'misSetProbability');
  requireProbability(repairResponse, 'repairResponse');
  return opportunities * misSetProbability * repairResponse;
}
