#!/usr/bin/env node
// Regression checks for the v2 conditional observation-scoring shell.

import {
  anomalySignal,
  conditionalSpeakerLogJoint,
  contextPosteriorFromCue,
  marginalSpeakerLogLikelihood,
  orderedLogitLogProbability,
} from '../js/joint-likelihood.mjs';

let checks = 0;
let failures = 0;

function ok(label, condition, detail = '') {
  checks += 1;
  if (!condition) {
    failures += 1;
    console.error(`FAIL ${label}${detail ? ` -- ${detail}` : ''}`);
  }
}

function close(label, actual, expected, tolerance = 1e-10) {
  ok(label, Math.abs(actual - expected) <= tolerance,
    `actual ${actual}, expected ${expected}`);
}

const model = {
  lectWeights: [0.5, 0.5],
  nodeRates: [[0.9], [0.1]],
  contextPrior: [1],
  cueLikelihoods: [[1]],
  utilitiesByContext: [[2]],
  outsideUtilitiesByContext: [0],
  repair: {
    intercept: -3,
    misSetWeight: 0.5,
    divergenceWeight: 0.4,
    dissonanceWeight: 0.2,
  },
  readout: {
    alpha: 1,
    processingWeight: 0.5,
    plausibilityWeight: 0.5,
    dissonanceWeight: 0.5,
  },
  rating: {
    intercept: 0,
    anomalyWeight: -2,
    decisionConfidenceWeight: 0.3,
    cutpoints: [-1, 0, 1],
  },
  confidence: {
    intercept: 0,
    evidenceWeight: 1,
    decisionWeight: 0.5,
    cutpoints: [-1, 0, 1],
  },
};

const targetObservation = { context: 0, cue: 0, outcome: 0 };

// 1. Exact marginalization over two lects and one node recovers the manually
// calculated population production probability.
{
  const result = marginalSpeakerLogLikelihood({ model, observations: [targetObservation] });
  const targetGivenAvailable = Math.exp(2) / (1 + Math.exp(2));
  close('marginal likelihood enumerates all latent states', result.evaluatedStates, 4);
  close('marginal likelihood matches analytic gated-choice probability',
    Math.exp(result.logLikelihood), 0.5 * targetGivenAvailable, 1e-12);
}

// 2. The conditional shell exposes the latent and observable channels as
// separate terms, so a repair observation cannot be accidentally counted twice.
{
  const speaker = { lectIndex: 0, inclusion: [true] };
  const base = conditionalSpeakerLogJoint({ model, speaker, observations: [targetObservation] });
  const repairedObservation = {
    ...targetObservation,
    repair: false,
    misSet: true,
    divergence: 2,
    footing: 1,
    prescriptiveDissonance: 0,
  };
  const withRepair = conditionalSpeakerLogJoint({ model, speaker, observations: [repairedObservation] });
  ok('conditional shell: production component is finite', Number.isFinite(base.components.production));
  ok('conditional shell: repair component is finite', Number.isFinite(withRepair.components.repair));
  close('conditional shell: repair enters once',
    withRepair.logLikelihood - base.logLikelihood, withRepair.components.repair);
}

// 3. Production candidates can require several construction nodes. Exact
// marginalization must enumerate nodes, not candidate labels.
{
  const multiNodeModel = {
    ...model,
    lectWeights: [1],
    nodeRates: [[0.5, 0.5]],
    candidateNodeIndices: [[0, 1]],
  };
  const result = marginalSpeakerLogLikelihood({
    model: multiNodeModel,
    observations: [targetObservation],
  });
  const targetGivenAvailable = Math.exp(2) / (1 + Math.exp(2));
  close('multi-node likelihood enumerates two latent nodes', result.evaluatedStates, 4);
  close('multi-node likelihood requires both nodes for production',
    Math.exp(result.logLikelihood), 0.25 * targetGivenAvailable, 1e-12);
}

// 4. Ratings and confidence are separate measurement channels conditional on
// a shared read-out, rather than direct observations of licensing.
{
  const observation = {
    ...targetObservation,
    rating: 1,
    confidenceRating: 2,
    readout: {
      statusEstimate: 0.2,
      evidenceConfidence: 0.9,
      decisionConfidence: 0.8,
      processingCost: 0.4,
      plausibilityCost: 0.2,
      prescriptiveDissonance: 0.1,
    },
  };
  const result = conditionalSpeakerLogJoint({
    model,
    speaker: { lectIndex: 0, inclusion: [true] },
    observations: [observation],
  });
  ok('measurement likelihood: rating is finite', Number.isFinite(result.components.rating));
  ok('measurement likelihood: confidence is finite', Number.isFinite(result.components.confidence));
  const signal = anomalySignal({
    statusEstimate: 0.2,
    processingCost: 0.4,
    plausibilityCost: 0.2,
    prescriptiveDissonance: 0.1,
    ...model.readout,
  });
  ok('anomaly signal remains bounded', signal > -1 && signal <= 0, `${signal}`);
}

// 5. The shell's current boundary is explicit: repair and read-out predictors
// are supplied covariates, so changing latent inclusion affects production but
// leaves those components unchanged.
{
  const observation = {
    context: 0,
    cue: 0,
    outcome: 'outside',
    repair: false,
    misSet: true,
    divergence: 2,
    footing: 1,
    rating: 1,
    confidenceRating: 2,
    readout: {
      statusEstimate: 0.2,
      evidenceConfidence: 0.9,
      decisionConfidence: 0.8,
    },
  };
  const included = conditionalSpeakerLogJoint({
    model, speaker: { lectIndex: 0, inclusion: [true] }, observations: [observation],
  });
  const excluded = conditionalSpeakerLogJoint({
    model, speaker: { lectIndex: 0, inclusion: [false] }, observations: [observation],
  });
  ok('conditional shell: production depends on latent inclusion',
    included.components.production !== excluded.components.production);
  close('conditional shell: repair is not yet inclusion-derived',
    included.components.repair, excluded.components.repair);
  close('conditional shell: rating is not yet inclusion-derived',
    included.components.rating, excluded.components.rating);
  close('conditional shell: confidence is not yet inclusion-derived',
    included.components.confidence, excluded.components.confidence);
}

// 6. Ordered-logit categories form a proper probability distribution.
{
  const cutpoints = [-1, 0, 1];
  const total = [0, 1, 2, 3].reduce((sum, category) => (
    sum + Math.exp(orderedLogitLogProbability(category, 0.2, cutpoints))
  ), 0);
  close('ordered logit categories normalize', total, 1, 1e-12);
}

// 7. q(c | cue) is derived from a context prior and cue likelihood, not used
// as a generative distribution in the joint model.
{
  const posterior = contextPosteriorFromCue({
    contextPrior: [0.7, 0.3],
    cueLikelihoods: [[0.9, 0.1], [0.1, 0.9]],
    cue: 1,
  });
  close('context posterior: first context', posterior[0], 0.07 / 0.34);
  close('context posterior: second context', posterior[1], 0.27 / 0.34);
  close('context posterior normalizes', posterior[0] + posterior[1], 1);
}

if (failures > 0) {
  console.error(`\n${failures}/${checks} joint-likelihood checks FAILED`);
  process.exit(1);
}
console.log(`All ${checks} joint-likelihood checks passed.`);
