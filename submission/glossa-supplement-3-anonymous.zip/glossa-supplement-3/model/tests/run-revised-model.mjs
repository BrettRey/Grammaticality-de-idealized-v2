#!/usr/bin/env node
// Regression checks for the v2 quantitative core. These assert the revised
// mathematical commitments, not the legacy Figure 4 prototype trajectories.

import {
  availabilityPowerPosteriorUpdate,
  availabilityPosteriorUpdate,
  decisionConfidence,
  discountEvidenceState,
  gatedChoiceProbabilities,
  makeEvidenceState,
  omissionEvidenceFromChoice,
  posteriorParameters,
  repairFlow,
  repairProbability,
  summary,
} from '../js/revised-engine.mjs';
import {
  REVISED_REGIMES,
  assemblyPrevalenceFromLects,
  candidateAvailabilityFromNodes,
  independentMarginalAssemblyPrevalence,
  marginalNodeRates,
  simulateEvidenceRegime,
} from '../js/revised-sim.mjs';

let checks = 0;
let failures = 0;

function ok(label, condition, detail = '') {
  checks += 1;
  if (!condition) {
    failures += 1;
    console.error(`FAIL ${label}${detail ? ` -- ${detail}` : ''}`);
  }
}

function close(label, actual, expected, tolerance = 1e-10) {
  ok(label, Math.abs(actual - expected) <= tolerance,
    `actual ${actual}, expected ${expected}`);
}

// 1. Discounting must preserve the baseline prior rather than forget it.
{
  let state = makeEvidenceState({ priorA: 2, priorB: 3, positiveEvidence: 16, negativeEvidence: 8 });
  for (let step = 0; step < 24; step += 1) {
    state = discountEvidenceState(state, 0.5);
  }
  const result = summary(state);
  close('quiet node returns to prior a', result.a, 2 + 16 / (2 ** 24), 1e-10);
  close('quiet node returns to prior b', result.b, 3 + 8 / (2 ** 24), 1e-10);
  close('quiet node returns to prior mean', result.mean, 0.4, 1e-6);
  close(
    'epistemic and heterogeneity terms recover predictive Bernoulli variance',
    result.epistemicVariance + result.heterogeneityVariance,
    result.mean * (1 - result.mean),
  );
}

// 2. The gated softmax is a normalized probability distribution with an
// unavailable candidate receiving no mass.
{
  const probabilities = gatedChoiceProbabilities({
    utilities: [1, 0], availability: [true, false], outsideUtility: -1,
  });
  close('gated choice normalizes', probabilities.candidates[0] + probabilities.candidates[1] + probabilities.outside, 1);
  close('unavailable candidate has zero probability', probabilities.candidates[1], 0);
}

// 3. The omission diagnostic reports both the exact LLR and the affine
// contrast needed by the availability posterior. A symmetric competitor gives
// log 2 information but a contrast of one half.
{
  const evidence = omissionEvidenceFromChoice({
    utilities: [0, 0],
    availability: [false, true],
    targetIndex: 0,
    observedOutcome: 1,
    outsideUtility: -30,
  });
  close('competitor omission has log-two evidence', evidence.logLikelihoodRatio, Math.log(2), 1e-8);
  ok('log likelihood ratio is not rho-star exactly', Math.abs(evidence.logLikelihoodRatio - 0.5) > 0.1);
  close('competitor omission has half-scale affine contrast',
    evidence.availabilityContrast, 0.5, 1e-8);

  const withEqualOutside = omissionEvidenceFromChoice({
    utilities: [0, 0],
    availability: [false, true],
    targetIndex: 0,
    observedOutcome: 1,
    outsideUtility: 0,
  });
  close('outside option enters exact omission normalization',
    withEqualOutside.logLikelihoodRatio, Math.log(3 / 2));
  close('outside option enters affine omission contrast',
    withEqualOutside.availabilityContrast, 1 / 3);
  ok('candidate-only rho-star gives the wrong outside-option LLR',
    Math.abs(withEqualOutside.logLikelihoodRatio - Math.log(2)) > 0.2);
}

// 4. The outside option can be nearly uninformative when the counterfactual
// candidate has low utility.
{
  const evidence = omissionEvidenceFromChoice({
    utilities: [-7, -7],
    availability: [false, false],
    targetIndex: 0,
    observedOutcome: 'outside',
    outsideUtility: 0,
  });
  ok('outside omission has small availability contrast',
    evidence.availabilityContrast < 0.002,
    `contrast ${evidence.availabilityContrast}`);
}

// 4b. The exact affine-likelihood mixture agrees with independent numerical
// integration, and the bounded Beta approximation preserves its first two
// moments. Limiting contrasts recover the expected conjugate updates.
{
  const state = makeEvidenceState({ priorA: 2.3, priorB: 3.1 });
  const contrasts = [0.2, 0.55, 0.9];
  const update = availabilityPosteriorUpdate(
    state,
    { targetCount: 2, omissionContrasts: contrasts },
  );
  const kernel = (theta, momentOrder) => (
    (theta ** (2.3 - 1 + 2 + momentOrder)) *
    ((1 - theta) ** (3.1 - 1)) *
    contrasts.reduce((product, contrast) => product * (1 - contrast * theta), 1)
  );
  const integrate = (fn, intervals = 20000) => {
    const width = 1 / intervals;
    let total = fn(0) + fn(1);
    for (let index = 1; index < intervals; index += 1) {
      total += (index % 2 === 0 ? 2 : 4) * fn(index * width);
    }
    return (width / 3) * total;
  };
  const normalizer = integrate((theta) => kernel(theta, 0));
  const numericalMean = integrate((theta) => kernel(theta, 1)) / normalizer;
  const numericalSecond = integrate((theta) => kernel(theta, 2)) / normalizer;
  const numericalVariance = numericalSecond - (numericalMean ** 2);
  close('affine mixture mean agrees with numerical integration',
    update.exactMoments.mean, numericalMean, 2e-10);
  close('affine mixture variance agrees with numerical integration',
    update.exactMoments.variance, numericalVariance, 2e-10);
  close('moment match preserves exact mean',
    update.matchedMoments.mean, update.exactMoments.mean, 1e-12);
  close('moment match preserves exact variance',
    update.matchedMoments.variance, update.exactMoments.variance, 1e-12);
  ok('third-moment approximation error is finite and reported',
    Number.isFinite(update.approximation.absoluteThirdMomentError));

  const repeatedContrast = 0.55;
  const finiteBatch = availabilityPosteriorUpdate(
    state,
    { targetCount: 2, omissionContrasts: Array(3).fill(repeatedContrast) },
  );
  const expectedBatch = availabilityPowerPosteriorUpdate(
    state,
    { targetPower: 2, omissionContrast: repeatedContrast, omissionPower: 3 },
  );
  close('power-likelihood quadrature agrees with exact finite mixture mean',
    expectedBatch.exactMoments.mean, finiteBatch.exactMoments.mean, 2e-10);
  close('power-likelihood quadrature agrees with exact finite mixture variance',
    expectedBatch.exactMoments.variance, finiteBatch.exactMoments.variance, 2e-10);

  const uninformative = availabilityPosteriorUpdate(
    makeEvidenceState({ priorA: 2, priorB: 3 }),
    { omissionContrasts: [0] },
  );
  close('zero contrast leaves a unchanged', posteriorParameters(uninformative.state).a, 2);
  close('zero contrast leaves b unchanged', posteriorParameters(uninformative.state).b, 3);
  const categorical = availabilityPosteriorUpdate(
    makeEvidenceState({ priorA: 2, priorB: 3 }),
    { targetCount: 1, omissionContrasts: [1] },
  );
  close('unit contrast plus target recovers conjugate a',
    posteriorParameters(categorical.state).a, 3);
  close('unit contrast plus target recovers conjugate b',
    posteriorParameters(categorical.state).b, 4);
}

// 5. Repair uses the paper's logistic link and the expected-flow helper has the
// stated N * P(mis-set) * r form.
{
  const intercept = Math.log(0.1 / 0.9);
  const baseline = repairProbability({ intercept, statusEstimate: 1 });
  const probability = repairProbability({
    intercept, statusEstimate: 0.2, divergence: 2, footing: 1, sensitivity: 0.8,
  });
  close('repair logistic intercept recovers baseline', baseline, 0.1);
  ok('repair probability rises with low status and divergence', probability > baseline,
    `${probability}`);
  ok('repair probability is bounded', probability >= 0 && probability <= 1, `${probability}`);
  close('repair flow', repairFlow({ opportunities: 20, misSetProbability: 0.3, repairResponse: 0.5 }), 3);
}

// 6. The four illustrative regimes follow from explicit parameters. The
// winnerless state requires its low candidate prior; no-evidence alone is not
// treated as exclusion.
{
  const end = (name, steps = 80, seed = 20260710) => (
    simulateEvidenceRegime(REVISED_REGIMES[name], steps, seed).rows.at(-1)
  );
  const licensed = end('licensed');
  ok('licensed: high mean', licensed.mean > 0.8, `${licensed.mean}`);
  ok('licensed: concentrated', licensed.concentration > 100, `${licensed.concentration}`);

  const preempted = end('preempted');
  ok('preempted: low mean', preempted.mean < 0.08, `${preempted.mean}`);
  ok('preempted: concentrated', preempted.concentration > 100, `${preempted.concentration}`);

  const starved = end('starved');
  close('starved: prior mean survives without opportunities', starved.mean, 0.5);
  close('starved: prior concentration survives without opportunities', starved.concentration, 2);

  const winnerless = end('winnerless');
  ok('winnerless: low mean needs low prior', winnerless.mean < 0.1, `${winnerless.mean}`);
  ok('winnerless: low concentration under uninformative avoidance', winnerless.concentration < 6,
    `${winnerless.concentration}`);
}

// 7. A latent-lect mixture determines multi-node assembly prevalence through
// joint inclusion, not through the product of marginal node rates.
{
  const correlatedLects = {
    weights: [0.5, 0.5],
    nodeRates: [[1, 1], [0, 0]],
  };
  const antiCorrelatedLects = {
    weights: [0.5, 0.5],
    nodeRates: [[1, 0], [0, 1]],
  };
  const marginals = marginalNodeRates(correlatedLects);
  close('latent lects: first marginal rate', marginals[0], 0.5);
  close('latent lects: second marginal rate', marginals[1], 0.5);
  close('latent lects: correlated assembly prevalence',
    assemblyPrevalenceFromLects(correlatedLects, [0, 1]), 0.5);
  close('latent lects: independent approximation is wrong',
    independentMarginalAssemblyPrevalence(correlatedLects, [0, 1]), 0.25);
  close('latent lects: anti-correlated assembly prevalence',
    assemblyPrevalenceFromLects(antiCorrelatedLects, [0, 1]), 0);

  const sampled = simulateEvidenceRegime({
    utilities: [0, 0],
    lectModel: correlatedLects,
    outsideUtility: -5,
    opportunitiesPerStep: 0,
    speakerCount: 1000,
    assemblyNodeIndices: [0, 1],
  }, 0, 5);
  const initial = sampled.rows[0];
  close('latent lects: reports exact theoretical prevalence',
    initial.theoreticalAssemblyPrevalence, 0.5);
  ok('latent lects: finite population tracks prevalence',
    Math.abs(initial.assemblyPopulationPrevalence - 0.5) < 0.06,
    `${initial.assemblyPopulationPrevalence}`);
  ok('latent lects: retains speaker lect assignments',
    sampled.lectAssignments.length === 1000);

  const mappedAvailability = candidateAvailabilityFromNodes(
    [true, false, true],
    [[0, 1], [2]],
  );
  ok('multi-node candidate: conjunctive gate blocks missing node', mappedAvailability[0] === false);
  ok('single-node candidate: independent gate remains available', mappedAvailability[1] === true);
  const multiNodeTarget = simulateEvidenceRegime({
    utilities: [0],
    lectModel: correlatedLects,
    candidateNodeIndices: [[0, 1]],
    outsideUtility: -5,
    opportunitiesPerStep: 0,
    speakerCount: 1000,
  }, 0, 5).rows[0];
  close('multi-node candidate: exact target prevalence uses both nodes',
    multiNodeTarget.theoreticalTargetPrevalence, 0.5);
  close('multi-node candidate: target and assembly prevalence coincide by default',
    multiNodeTarget.theoreticalTargetPrevalence, multiNodeTarget.theoreticalAssemblyPrevalence);
}

// 7b. Under data generated by the declared gated-choice model, the repaired
// filter recovers the sampled population availability rate across the interior.
{
  [0.1, 0.3, 0.5, 0.7, 0.9].forEach((trueRate, index) => {
    const run = simulateEvidenceRegime({
      utilities: [0, 0],
      trueRates: [trueRate, 1],
      outsideUtility: -4,
      speakerCount: 5000,
      opportunitiesPerStep: 100,
    }, 100, 710 + index);
    const final = run.rows.at(-1);
    ok(`availability recovery at theta=${trueRate}`,
      Math.abs(final.mean - final.targetPopulationPrevalence) < 0.03,
      `${final.mean} vs sampled ${final.targetPopulationPrevalence}`);
  });
}

// 8. Evidence confidence and decision confidence are distinct. A precisely
// known 50/50 community is not a confident in/out verdict at threshold 0.5.
{
  const divided = makeEvidenceState({
    priorA: 1, priorB: 1, positiveEvidence: 99, negativeEvidence: 99,
  });
  const excluded = makeEvidenceState({
    priorA: 1, priorB: 1, positiveEvidence: 0, negativeEvidence: 198,
  });
  ok('decision confidence: divided population is highly concentrated',
    summary(divided).concentration === 200);
  close('decision confidence: divided population stays at chance',
    decisionConfidence(divided, 0.5), 0.5, 1e-8);
  ok('decision confidence: concentrated exclusion is decisive',
    decisionConfidence(excluded, 0.5) > 0.999);
  let missingThresholdRejected = false;
  try {
    decisionConfidence(divided);
  } catch (error) {
    missingThresholdRejected = error instanceof TypeError;
  }
  ok('decision confidence: situation threshold is explicit', missingThresholdRejected);
}

if (failures > 0) {
  console.error(`\n${failures}/${checks} revised-model checks FAILED`);
  process.exit(1);
}
console.log(`All ${checks} revised-model checks passed.`);
