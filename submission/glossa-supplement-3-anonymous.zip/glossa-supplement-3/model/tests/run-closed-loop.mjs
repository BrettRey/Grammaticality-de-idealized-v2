#!/usr/bin/env node
// Regression checks for the finite-population closed-loop stress test.

import {
  adoptionProbability,
  basinSeparationDiagnostic,
  deterministicMeanFieldMap,
  eigenvalues3,
  endpointConcentrationDiagnostic,
  expectedEvidenceFlow,
  findMeanFieldFixedPoints,
  meanFieldJacobian,
  reducedMeanFieldResponse,
  simulateClosedLoop,
  stationaryEvidenceAtTheta,
  tailMeanTheta,
} from '../js/closed-loop-sim.mjs';
import { makeEvidenceState } from '../js/revised-engine.mjs';

let checks = 0;
let failures = 0;

function ok(label, condition, detail = '') {
  checks += 1;
  if (!condition) {
    failures += 1;
    console.error(`FAIL ${label}${detail ? ` -- ${detail}` : ''}`);
  }
}

// 1c. Equilibrium timing and stability belong to the full three-state map.
// The reduced H(theta) crossing is retained only as a locator.
{
  const params = {
    adoptionFamily: 'posteriorThreshold',
    outsideUtility: -4,
    opportunitiesPerStep: 12,
    observationProbability: 0.6,
    deltaM: 0.96,
  };
  const mapped = deterministicMeanFieldMap({ theta: 0.5, a: 1, b: 1 }, params);
  ok('mean-field map returns a valid theta', mapped.theta > 0 && mapped.theta < 1);
  ok('mean-field map returns valid Beta parameters', mapped.a > 0 && mapped.b > 0);
  ok('base mean-field update does not bind the variance clamp',
    !mapped.approximationVarianceClampApplied);
  ok('base mean-field update reports sub-Bernoulli variance',
    mapped.approximationVarianceToBernoulliRatio > 0 &&
      mapped.approximationVarianceToBernoulliRatio < 1);
  const jacobian = meanFieldJacobian({ theta: 0.5, a: 2, b: 2 }, params);
  ok('full mean-field Jacobian is three by three',
    jacobian.length === 3 && jacobian.every((row) => row.length === 3));
  const diagonalEigenvalues = eigenvalues3([[1, 0, 0], [0, 2, 0], [0, 0, 3]]);
  close('three-state eigensolver returns the dominant diagonal eigenvalue',
    diagonalEigenvalues[0].modulus, 3, 1e-10);
  const fixedPoints = findMeanFieldFixedPoints(params, { gridSize: 40, tolerance: 1e-9 });
  ok('repaired-filter base cell has two endpoint and one interior fixed point',
    fixedPoints.length === 3,
    `${fixedPoints.map((point) => point.theta)}`);
  const interior = fixedPoints.find((point) => point.theta > 0.1 && point.theta < 0.9);
  ok('base interior fixed point is unstable in the full map', interior && !interior.stable,
    `${interior?.spectralRadius}`);
  ok('base endpoint fixed points are stable in the full map',
    fixedPoints.filter((point) => point.theta <= 0.1 || point.theta >= 0.9)
      .every((point) => point.stable));
  ok('reduced multiplier is not reported as the full return rate',
    Math.abs(interior.reducedMultiplier - interior.spectralRadius) > 0.1,
    `${interior.reducedMultiplier} vs ${interior.spectralRadius}`);
}

// 1d. The full-map stationary reduction has a local cusp under effective
// evidence inflow and the independently supplied adoption threshold. This is
// a bifurcation regression check, not a Thom-catastrophe or empirical claim.
{
  const cusp = {
    theta: 0.370956983661099,
    inflow: 0.47915596953859513,
    threshold: 0.5520475691541454,
  };
  const common = {
    adoptionFamily: 'posteriorThreshold',
    outsideUtility: -4,
    observationProbability: 0.6,
    deltaM: 0.96,
    inclusionUpdateRate: 0.08,
  };
  const residual = (theta) => reducedMeanFieldResponse(theta, {
    ...common,
    opportunitiesPerStep: cusp.inflow,
    adoptionThreshold: cusp.threshold,
  }, { tolerance: 1e-11, maxIterations: 10000 }).response - theta;
  const step = 0.002;
  const center = residual(cusp.theta);
  const lower = residual(cusp.theta - step);
  const upper = residual(cusp.theta + step);
  const lowerTwo = residual(cusp.theta - 2 * step);
  const upperTwo = residual(cusp.theta + 2 * step);
  const first = (upper - lower) / (2 * step);
  const second = (upper - 2 * center + lower) / (step ** 2);
  const third = (upperTwo - 2 * upper + 2 * lower - lowerTwo) / (2 * step ** 3);
  ok('cusp candidate has a near-zero fixed-point residual', Math.abs(center) < 1e-7,
    `${center}`);
  ok('cusp candidate has a near-zero first theta derivative', Math.abs(first) < 1e-4,
    `${first}`);
  ok('cusp candidate has a near-zero second theta derivative', Math.abs(second) < 1e-3,
    `${second}`);
  ok('cusp candidate has a non-zero cubic term', Math.abs(third) > 1, `${third}`);
  const stationary = stationaryEvidenceAtTheta(cusp.theta, {
    ...common,
    opportunitiesPerStep: cusp.inflow,
    adoptionThreshold: cusp.threshold,
  }, { tolerance: 1e-11, maxIterations: 10000 });
  const cuspEigenvalues = eigenvalues3(meanFieldJacobian({
    theta: cusp.theta,
    a: stationary.state.a,
    b: stationary.state.b,
  }, {
    ...common,
    opportunitiesPerStep: cusp.inflow,
    adoptionThreshold: cusp.threshold,
  }, 1e-6));
  ok('cusp candidate has one unit eigenvalue',
    Math.abs(cuspEigenvalues[0].modulus - 1) < 1e-5,
    `${cuspEigenvalues.map((value) => value.modulus)}`);
  ok('cusp candidate has two stable transverse eigenvalues',
    cuspEigenvalues.slice(1).every((value) => value.modulus < 1));
  const inside = findMeanFieldFixedPoints({
    ...common,
    opportunitiesPerStep: 0.4911579126575991,
    adoptionThreshold: 0.5503312418860986,
  }, { gridSize: 80, tolerance: 1e-9 });
  const outside = findMeanFieldFixedPoints({
    ...common,
    opportunitiesPerStep: 0.48915596953859514,
    adoptionThreshold: 0.5520475691541454,
  }, { gridSize: 80, tolerance: 1e-9 });
  ok('inside the local cusp wedge there are three fixed points', inside.length === 3,
    `${inside.map((point) => point.theta)}`);
  ok('outside the local cusp wedge there is one fixed point', outside.length === 1,
    `${outside.map((point) => point.theta)}`);
}

// 1b. The expected-observation diagnostic exposes the target probability and
// affine omission contrast without inventing additive pseudo-count balance.
{
  const middle = expectedEvidenceFlow({ theta: 0.5, outsideUtility: -4 });
  ok('expected observations: target outcome has positive probability',
    middle.targetOutcomeProbability > 0 && middle.targetOutcomeProbability < 0.5);
  ok('expected observations: omission contrast is bounded',
    middle.omissionAvailabilityContrast > 0 && middle.omissionAvailabilityContrast < 1);
  const starved = expectedEvidenceFlow({ theta: 0.5, outsideUtility: 5 });
  ok('expected observations: dominant outside option weakens omission information',
    starved.omissionAvailabilityContrast < middle.omissionAvailabilityContrast,
    `${starved.omissionAvailabilityContrast} vs ${middle.omissionAvailabilityContrast}`);
}

function close(label, actual, expected, tolerance = 1e-10) {
  ok(label, Math.abs(actual - expected) <= tolerance,
    `actual ${actual}, expected ${expected}`);
}

// 1. The three h_kappa families are distinct, bounded, and directional.
{
  const neutral = makeEvidenceState();
  const high = makeEvidenceState({ positiveEvidence: 18 });
  const low = makeEvidenceState({ negativeEvidence: 18 });
  close('mean response uses posterior mean',
    adoptionProbability(high, { family: 'mean' }), 19 / 20);
  close('logistic response is neutral at its threshold',
    adoptionProbability(neutral, { family: 'logisticMean', threshold: 0.5, slope: 8 }), 0.5);
  ok('posterior-threshold response rises with positive evidence',
    adoptionProbability(high, { family: 'posteriorThreshold' }) > 0.99);
  ok('posterior-threshold response falls with negative evidence',
    adoptionProbability(low, { family: 'posteriorThreshold' }) < 0.01);
}

// 2. Zero inclusion updating leaves states unchanged even when evidence moves.
{
  const run = simulateClosedLoop({
    speakerCount: 40,
    initialInclusionRate: 0.7,
    inclusionUpdateRate: 0,
    opportunitiesPerStep: 10,
  }, 30, 17);
  run.rows.forEach((row) => close(`zero inclusion updating freezes theta at step ${row.step}`, row.theta, 0.7));
  ok('evidence still moves when inclusion is frozen', run.rows.at(-1).concentrationMean > 2);
}

// 3. With no opportunities, filters remain at their prior while inclusion can
// transition remains defined by the prior-driven adoption response.
{
  const run = simulateClosedLoop({
    speakerCount: 60,
    opportunitiesPerStep: 0,
    adoptionFamily: 'mean',
    inclusionUpdateRate: 0.2,
  }, 50, 21);
  run.rows.forEach((row) => {
    close(`quiet population keeps prior evidence mean at step ${row.step}`, row.evidenceMean, 0.5);
    close(`quiet population keeps prior concentration at step ${row.step}`, row.concentrationMean, 2);
  });
}

// 4. The same seed and parameters reproduce the exact path.
{
  const params = {
    speakerCount: 32,
    opportunitiesPerStep: 6,
    adoptionFamily: 'logisticMean',
  };
  const first = simulateClosedLoop(params, 40, 99);
  const second = simulateClosedLoop(params, 40, 99);
  ok('closed-loop simulation is seed reproducible',
    JSON.stringify(first.rows) === JSON.stringify(second.rows));
}

// 4b. A basin initialization can align binary inclusion with an accumulated
// evidence history instead of pairing an extreme population with neutral priors.
{
  const high = simulateClosedLoop({
    speakerCount: 20,
    initialInclusionRate: 0.9,
    initialEvidenceStrength: 38,
    opportunitiesPerStep: 0,
    inclusionUpdateRate: 0,
  }, 0, 3).rows[0];
  close('coherent high initialization sets the intended evidence mean', high.evidenceMean, 0.88);
  close('coherent initialization carries finite evidence concentration', high.concentrationMean, 40);
}

// 4bb. A deterministic fixed point can initialize the stochastic simulator
// exactly, including moment-matched states below a baseline shape parameter.
{
  const exact = simulateClosedLoop({
    speakerCount: 20,
    initialInclusionRate: 0.25,
    initialEvidenceState: { a: 0.95, b: 6.5 },
    opportunitiesPerStep: 0,
    inclusionUpdateRate: 0,
  }, 0, 13).rows[0];
  close('exact evidence initialization preserves the requested mean',
    exact.evidenceMean, 0.95 / 7.45);
  close('exact evidence initialization preserves the requested concentration',
    exact.concentrationMean, 7.45);
}

// 4c. Under an explicit heterogeneous-prior condition, loss of opportunities
// lets speaker evidence means spread as their common recent evidence decays.
{
  const run = simulateClosedLoop({
    speakerCount: 80,
    initialInclusionRate: 0.9,
    initialEvidenceStrength: 40,
    priorMeanSpread: 0.25,
    opportunitiesPerStep: 0,
    deltaM: 0.9,
    inclusionUpdateRate: 0,
  }, 80, 44);
  ok('heterogeneous priors: evidence-mean dispersion rises after evidence loss',
    run.rows.at(-1).evidenceMeanVariance > 4 * run.rows[0].evidenceMeanVariance,
    `${run.rows[0].evidenceMeanVariance} -> ${run.rows.at(-1).evidenceMeanVariance}`);
}

// 5. Inclusion shocks reset the empirical population rate but not the evidence
// state. The recorded post-transition theta may move immediately afterward.
{
  const run = simulateClosedLoop({
    speakerCount: 100,
    inclusionUpdateRate: 0,
    opportunitiesPerStep: 0,
    shocks: [{ step: 8, inclusionRate: 0.23 }],
  }, 12, 7);
  close('shock sets an exact finite-population inclusion rate', run.rows[8].theta, 0.23);
  close('shock does not reset evidence', run.rows[8].evidenceMean, 0.5);
  ok('shock is recorded', run.rows[8].shockInclusionRate === 0.23);
}

// 5b. An evidence shock changes the slow filter state without directly
// changing population inclusion, allowing full-state return tests.
{
  const run = simulateClosedLoop({
    speakerCount: 100,
    initialInclusionRate: 0.23,
    inclusionUpdateRate: 0,
    opportunitiesPerStep: 0,
    evidenceShocks: [{ step: 8, evidenceRate: 0.8, evidenceStrength: 18 }],
  }, 12, 9);
  close('evidence shock leaves finite-population inclusion unchanged', run.rows[8].theta, 0.23);
  close('evidence shock sets the declared Beta mean', run.rows[8].evidenceMean, 0.77);
  close('evidence shock sets the declared concentration', run.rows[8].concentrationMean, 20);
  ok('evidence shock is recorded', run.rows[8].shockEvidenceRate === 0.8);
}

// 6. Tail summaries and the operational endpoint diagnostic have pinned logic.
{
  const syntheticRun = { rows: [
    { theta: 0.1 }, { theta: 0.2 }, { theta: 0.8 }, { theta: 1.0 },
  ] };
  close('tail mean uses requested final fraction', tailMeanTheta(syntheticRun, 0.5), 0.9);
  const diagnostic = endpointConcentrationDiagnostic([
    0.05, 0.08, 0.1, 0.12, 0.15, 0.85, 0.88, 0.9, 0.92, 0.95,
  ]);
  ok('endpoint diagnostic occupies both basins', diagnostic.bothBasinsOccupied);
  ok('endpoint diagnostic identifies endpoint concentration', diagnostic.endpointConcentrated);
  close('endpoint diagnostic has no central mass here', diagnostic.centralFraction, 0);
  const basin = basinSeparationDiagnostic(
    [0.04, 0.08, 0.12, 0.16],
    [0.84, 0.88, 0.92, 0.96],
  );
  ok('basin diagnostic identifies low retention', basin.lowRetentionFraction === 1);
  ok('basin diagnostic identifies high retention', basin.highRetentionFraction === 1);
  ok('basin diagnostic identifies separated attraction', basin.basinSeparated);
}

// 7. An informative competitor creates feedback in the closed loop, whereas a
// dominant outside option supplies much less evidence under the same seed.
{
  const common = {
    speakerCount: 60,
    initialInclusionRate: 0.2,
    opportunitiesPerStep: 12,
    observationProbability: 0.7,
    inclusionUpdateRate: 0.08,
    adoptionFamily: 'posteriorThreshold',
    deltaM: 0.96,
  };
  const informative = simulateClosedLoop({ ...common, outsideUtility: -5 }, 100, 31);
  const starved = simulateClosedLoop({ ...common, outsideUtility: 5 }, 100, 31);
  ok('informative niche accumulates more evidence than outside-dominated niche',
    informative.rows.at(-1).concentrationMean > starved.rows.at(-1).concentrationMean,
    `${informative.rows.at(-1).concentrationMean} vs ${starved.rows.at(-1).concentrationMean}`);
}

if (failures > 0) {
  console.error(`\n${failures}/${checks} closed-loop checks FAILED`);
  process.exit(1);
}
console.log(`All ${checks} closed-loop checks passed.`);
