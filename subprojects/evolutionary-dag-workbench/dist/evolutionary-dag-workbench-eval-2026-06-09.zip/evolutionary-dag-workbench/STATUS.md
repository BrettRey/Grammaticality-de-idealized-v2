# Evolutionary DAG Workbench - Status

**Parent:** `Grammaticality_de_idealized`
**Created:** 2026-06-07
**Stage:** Active adversarial iteration
**Public state:** Private working subproject; no public claims or submission state.

## Current State

The subproject is now active as a discovery-first workbench for exploring rival conceptual
representations about grammaticality. The existing OVMG, detector, operator-stratum, usage-based,
processing-based, and normativity-based models are treated as seed graph families, not as
conclusions or targets to vindicate.

Fifty-five adversarial passes/synthesis steps have been run. All numeric scores remain zero. Seven
current modules have `scoped_module` labels tied to protocol-bound or held-out `scope-only`
evaluations. The original scope-only evaluations now include card-level requirements and activated
paths. The held-out CGEL evaluations also include card-level requirements and activated paths
without authorizing score movement. The agreement and center-embedding cards have now been
converted into protocol-bound evaluations against the operator-gap, dynamic/context, and
task-separated modules. Their repeated processing/naturalness gap justified a scoped
`processing-naturalness-perturbation-candidate`.
The clause-type/interjection pair has now exposed a distinct uptake/operator boundary gap, which
justified a scoped `uptake-operator-boundary-candidate`.
The frequent-condemned-form pass did not justify a new graph: `DYN` and `TASK` cover the relevant
production/condemnation/attribution split, while `CAT` is out of scope.
The fused-head NP pass also did not justify a new graph: `OPG` covers the core constructional
support/recoverability split, while `CAT` and `SEL` partly cover category/function and
selection-adjacent dimensions only.
The held-out CGEL evaluations now include machine-readable `prediction_tests` with pass/fail
conditions; score-change evaluations now require prediction tests.
Eight held-out CGEL cards have source-checked contrast examples, and the prediction-test inventory
now records checked evidence statuses: fourteen `passed`, four `mixed`, and one `inconclusive`.
No graph has a `general_account` score. The current scoring schema includes `projective_power` and
`theory_preservation_penalty` so held-out prediction and anti-alignment discipline are visible.
The Gibson source pass added five processing/dependency cards without changing graph machinery:
dependency-locality alternations, garden-path temporary ambiguity, noisy-channel overacceptance,
island construction variation, and legalese center embedding.
The same card pass added a local minimal-pair card for `I have five years`, separating contextual
anchoring from ad hoc rescue.
Those new cards now have protocol-bound no-score-change evaluations. `PROC` survives the locality
and garden-path cards and partly survives noisy-channel overacceptance. `UPT` survives the duration
frame minimal pair while `OPG` only partly survives it. `OPG` and `UPT` both partly survive island
construction variation. `DYN` and `TASK` partly survive legalese, but both lack direct processing
or comprehension-cost machinery.
The nineteenth pass added controlled constructs for repair-neighbour distance, constructional frame
fit, and construction-specific dependency licensing. The resulting
`frame-specific-dependency-licensing-candidate` is a scoped module for the `I have five years`
minimal pair and Gibson's island construction-variation card. It does not replace `OPG`'s
opportunity/preemption machinery or `UPT`'s broader uptake/repertoire boundary machinery.
The twentieth pass ran legalese against `PROC`. It partly survives: `PROC` captures processing,
naturalness, comprehension, and preference pressure, while `DYN` and `TASK` remain needed for
official genre fit, professional production, and institutional persistence. No genre-processing
hybrid graph is justified yet.
The twenty-first pass added `repair-neighbour-reconstruction-candidate` after noisy-channel
overacceptance exposed that general recoverability is too broad. The candidate survives that card as
a one-card module but remains unscored and has no `scoped_module` label.
The twenty-second pass split the noisy-channel omnibus into four sharper Gibson-backed cards:
missing-verb-phrase illusion, depth-charge semantic illusion, comparative illusion as
noisy-channel repair, and edit-distance/length acceptability. `RNR` survives missing-verb repair,
partly survives depth-charge and comparative illusions, and partly survives edit-distance
acceptability while exposing a missing length/information-normalization construct.
The twenty-third pass added `information-normalized-repair-candidate`, separating raw repair
distance, target information mass, and information-normalized repair distance. It survives the
edit-distance/length card and preserves the missing-verb repair path, but remains unscored and has
no `scoped_module` label.
The twenty-fourth pass tested INR against depth-charge and comparative-illusion cards. It partly
survives both, confirming that normalized repair distance should not absorb meaning-prior or
category-analysis machinery.
The twenty-fifth pass added `meaning-prior-reconstruction-candidate`, separating intended-meaning
plausibility from literal-composition coherence. It survives the depth-charge card and partly
survives comparative illusion, where category/function analysis remains outside the graph.
The twenty-sixth pass added three local minimal-pair cards from Brett: perfect with a definite
past-time expression, nearest-noun agreement attraction, and `know`/`believe`/`wonder` complement
selection. `FRAME` partly survives the perfect/past-time card, `PROC` partly survives nearest-noun
agreement attraction, and `SEL` survives the attitude-complement card as a scoped
complement-selection module. No new graph is justified yet.
The twenty-seventh pass added the `allowed to do` / `allowed doing` cohort contrast. `SEL` partly
survives because it handles complement-selection structure, but it lacks speaker/cohort identity,
production probability, and diachronic stabilization nodes needed for the adult/children contrast.
No new graph is justified yet.
The twenty-eighth pass added a targeted source-backed CGEL discriminator pack: continuative perfect
with `since`, catenative complement-form selection, proximity agreement error, and collective/
number-transparent agreement overrides. All four partly survive their target modules. The repeated
partial-survival pattern strengthens pressure for temporal-anchor, catenative-complement subtype,
and agreement-controller/retrieval constructs, but still does not justify a new graph.
The twenty-ninth pass added one more source-backed card in each repeated pressure zone:
present-perfect `already` plus `yesterday`, allow/prevent complement selection, and coordination
agreement resolution. The temporal and catenative cards remain pressure without mutation. The
coordination agreement card crossed the mutation threshold, producing
`agreement-controller-override-candidate`, a narrow unscored candidate with no `scoped_module`
label because it was built from the current agreement cards rather than held-out evidence.
The thirtieth pass added `measure-agreement-override-cgel` as a held-out test of
`agreement-controller-override-candidate`. The graph survives the measure-NP singular override
without adding nodes, giving first held-out support for the agreement module. It remains unscored and
has no `scoped_module` label pending at least one more held-out agreement subtype.
The thirty-first pass added `fused-determiner-head-agreement-cgel` as a second held-out agreement
subtype. The graph survived without adding nodes, so `agreement-controller-override-candidate` now
has a held-out `scope-only` evaluation and a `scoped_module` label. Numeric scores remain zero.
The thirty-second pass did not mutate any graph. It added concrete source/data pointers for the two
remaining mixed prediction cells: pronoun policy/audience design and rare transparent-relative
opportunity thresholds.
The thirty-third pass converted the rare transparent-relative data-pointer lane into an explicit
opportunity-denominator measurement design. It still does not run new corpus data or authorize score
movement.
The thirty-fourth pass added a source-backed measurement-validity card from Kauf et al. (2023) on
ANN-to-brain similarity. `PROC` and `CAT` partly survive because they enforce measurement-channel
discipline, while `OPG` is out of scope as a general account. No graph mutation or score movement
follows.
The thirty-fifth pass ran Lane A of the transparent-relative opportunity-denominator measurement
design. The local transparent-free-relative sources support a subtype-conditioned result:
attributional `call`-type contexts have sampled positive scoped attestation, while `seem`/`appear`
AP-transparent contexts show checked zero genuine cases over a meaningful opportunity denominator.
`OPG` therefore passes the `transparent-rare-relative-prediction` for this source lane only. Lane B,
independent relative `whose`, remains unrun, and no graph mutation or score movement follows.
The thirty-sixth pass converted the remaining pronoun/audience mixed cell into an explicit task
design. The design specifies contrast cells and separate response channels for reference tracking,
feature/personhood fit, reported acceptability, grammaticality attribution, social sanction, and
norm orientation. The relevant prediction tests remain `mixed` until actual task data exist.
The thirty-seventh pass reviewed the independent-relative-`whose` lane. It records an
experiment-ready low-opportunity design, power-analysis summary, and LLM/simulation outputs, but
keeps the lane distinct from human or corpus evidence. No graph mutation, score movement, or new
passed human-evidence cell follows.
The thirty-eighth pass tested the comparative-illusion noisy-channel card against `CAT`. `CAT`
partly survives: it handles category-analysis and measurement-task leakage while leaving repair
distance and intended-meaning-prior machinery to `INR`/`RNR` and `MPR`. No graph mutation or score
movement follows.
The thirty-ninth pass crossed the temporal-anchor mutation threshold. It added
`temporal-anchor-alignment-candidate`, built from the perfect-definite-past-time, continuative
perfect, already-plus-yesterday, narrative-present, and modal-perfect-by-now cards. The graph keeps
tense/aspect value, modal temporal inference, temporal anchor expression, temporal-anchor fit,
current relevance, continuative interval, experiential frame, and narrative perspective separate.
It survives the built-on temporal cards, but it is unscored and has no `scoped_module` label because
no held-out temporal card has tested it yet.
The fortieth pass consolidated number construal/realization against
`agreement-controller-override-candidate`. The graph survives collective, coordination, measure,
fused determiner-head, and proximity-error cards without mutation: notional basis, controller
identification, override pattern, feature alignment, and retrieval-attractor salience are enough for
the current number-realization bundle. No score movement follows.
The forty-first pass added `modal-preterite-remoteness-cgel` as a held-out test for
`temporal-anchor-alignment-candidate`. `TEMP` partly survives because it avoids treating preterite
form as simple past-time anchoring, but it lacks a modal-remoteness or remote-conditional frame
construct. The held-out result blocks any scoped label for `TEMP` and does not justify mutation from
one card alone.
The forty-second pass added `backshifted-preterite-orientation-cgel` as a second held-out test for
`TEMP`. It partly survives and shows that the missing construct is broader than modal remoteness:
the graph needs a temporal-orientation frame distinguishing deictic, matrix/report-supplied,
modal-remote, narrative, and other construction-supplied orientation sources.
The forty-third pass recorded `AGR` as the first COCA projection vertical slice. It adds a protocol
and data scaffold that improves on the Linguistic Transparency COCA pilot by separating discovery
from confirmation, requiring opportunity denominators, preserving reproducible KWIC coding, and
estimating uncertainty before any projective score movement.
The follow-on run harness, `scripts/run_agr_coca_queries.py`, expands the registered `AGR` query
plan into concrete English-Corpora.org wrapper calls. The first live run exposed that raw list
counts need KWIC filtering before they can support projection claims.
The live external-feedback queue is recorded in `notes/live-feedback-queue-2026-06-09.md`: projection
remains first, followed by compression/ablation pressure, critic-verdict variance checks, and modest
edge semantics. The immediate edge-semantics consistency fix softened `causal` in
`ontology/edge-types.yaml` from interventionist DAG language to directional explanatory dependence.
The first compression screen is recorded in
`notes/scoped-module-compression-audit-2026-06-09.md`, supported by
`scripts/audit_module_overlap.py`. It finds no merge/kill action justified by node overlap alone,
but identifies `FDL`/`UOB` as the best future merger test and `OPG`/`DYN` as the best overfitting
guard.
The first live COCA tranche is recorded in
`notes/agr-coca-bunch-animate-raw-list-pass-2026-06-09.md`: `bunch-animate-confirmatory` ran as
raw list-count queries and returned 72 plural-agreement hits versus 6 singular-agreement hits across
`a bunch of people/kids` with `are/were/is/was`. This is raw unfiltered production evidence only;
KWIC filtering and denominator work are still required before any evaluation or score movement.
The follow-on KWIC-filtered tranche is recorded in
`notes/agr-coca-bunch-animate-kwic-filter-pass-2026-06-09.md`. The repo-local
`scripts/fetch_coca_kwic_from_list.mjs` retrieves KWIC rows by clicking COCA list-result links,
which proved more reliable than direct KWIC form submission. The filtered target counts are 71
plural-agreement rows versus 1 singular-agreement row. Five of the six raw singular hits were
non-subject false positives. This supports the registered `AGR` direction for animate plural
complements but remains one narrow corpus tranche; it does not authorize score movement.
The inanimate contrast tranche is recorded in
`notes/agr-coca-bunch-inanimate-kwic-filter-pass-2026-06-09.md`. Across `a bunch of
flowers/things` with `are/were/is/was`, raw counts were sparse and KWIC-filtered target counts were
1 plural row versus 1 singular row. This differs sharply from the animate tranche and supports
treating member construal/animacy as a real conditioning pressure, but the cell is too sparse for
score movement or a stable inanimate-profile estimate.
The first non-`bunch` `AGR` corpus tranche is recorded in
`notes/agr-coca-majority-minority-kwic-filter-pass-2026-06-09.md`. Across `a/the majority of
people` and `a minority of voters`, KWIC-filtered target counts were 105 plural-agreement rows and
0 singular-agreement rows. The positive evidence comes from the `majority` cells; both registered
`minority` cells returned zero raw rows. This supports cross-construction portability for the
agreement-controller module, while still not authorizing score movement.
The COCA lane is now bound into the evaluation layer by
`evaluations/protocol-tests/agreement-controller-override-coca-projection-2026-06-09.json`. That
evaluation records the animate `bunch` projection as passed, the inanimate `bunch` contrast as
mixed/sparse, the majority portability test as passed, and the minority direct-query cells as
inconclusive. Adding the evaluation exposed a missing production-output bridge in `AGR`, so
`agreement-controller-override-candidate` now includes a profiled `community_licensing ->
production_probability` edge. This is a measurement/projection bridge only; it does not equate raw
frequency with licensing and does not move scores.
The known-QN calibration tranche is recorded in
`notes/agr-coca-known-qn-calibration-2026-06-09.md`. It reproduces expected directions after KWIC
filtering: `a number of people` yields 98 target plural rows, `a lot of money is` yields 42 target
singular rows, and `a lot of money are` yields 0 licensed target plural rows after filtering. One
counter-direction row is retained as denominator-only nonstandard/error evidence. This calibrates
the COCA/KWIC measurement lane but does not add projective credit or move scores.
The partitive raw-list tranche is recorded in
`notes/agr-coca-partitive-raw-list-pass-2026-06-09.md`. It confirms the expected denominator
contrast among direct strings: `lots of people` (3875) and `plenty of people` (1563) are common,
`lots/plenty of the people` are rare (5/1), and `the rest of the people` (272) greatly outnumbers
`the rest of people` (12). This is phrase-count denominator design only; it does not code agreement
or evaluate `AGR` outcome predictions.
The partitive finite-agreement follow-up is recorded in
`notes/agr-coca-partitive-agreement-raw-list-pass-2026-06-09.md`. Raw present-tense list counts are
plural-dominant across usable people frames: `lots of people are` 287, `plenty of people are` 65,
and `the rest of the people are` 15, versus only `lots of people is` 5 and zero rows for the other
singular cells. This is still raw unfiltered evidence. The next data step is KWIC filtering the five
`lots of people is` rows plus the moderate positive `plenty` and `rest` cells, and deciding whether
to sample or fully filter the 287-row `lots of people are` cell.
The targeted KWIC follow-up is recorded in
`notes/agr-coca-partitive-agreement-targeted-kwic-pass-2026-06-09.md`. The five
`lots of people is` rows yield 0 licensed target singular rows after filtering; the filtered
positive subset yields 63 target `plenty of people are` rows and 14 target
`the rest of the people are` rows.
The forty-fourth pass is recorded in
`notes/agr-coca-lots-people-are-sample-kwic-pass-2026-06-09.md`. A pre-declared 100-row bounded
KWIC sample from the high-count `lots of people are` cell yielded 100 target plural-agreement rows.
The partitive/QN people-frame prediction therefore moved provisionally from `mixed` to `passed`:
the sample/filtered evidence was 177 plural target rows versus 0 licensed target singular rows.
This was evidence movement only, not numeric score movement, because the largest cell was
sample-coded rather than fully filtered.
`evaluations/protocol-tests/agreement-controller-override-coca-projection-2026-06-09.json` now
records the partitive/QN people-frame result as `mixed` after the later critic-verdict variance
check.
The forty-fifth pass is recorded in
`notes/agr-coca-surface-head-baseline-discriminator-2026-06-09.md` and
`data/agr-coca-projection/baseline-discriminator.csv`. It makes the baseline comparison explicit:
animate `bunch`, `majority`, and `the rest of the people` are the clean cells where a simple
surface-head-number account predicts the wrong dominant direction. `lots/plenty of people` remain
supportive portability evidence rather than clean baseline-discriminator cells. No graph mutation or
score movement follows.
The forty-sixth pass is recorded in `notes/agr-coca-measurement-audit-2026-06-09.md`. It completes
the first false-positive/false-omission audit for the AGR COCA lane. Existing coded exact-query rows
show low false-positive pressure in the animate `bunch`, `majority`, and selected partitive/QN
cells; the inanimate `bunch` contrast remains sparse/high-noise. A bounded 98-row denominator sample
for `the majority of people` found 37 omitted plural-agreement opportunities and 0 omitted singular
opportunities, so the direct `are/is` query undercounts the plural direction but does not reverse it.
The COCA projection evaluation now includes this as a passed measurement-audit prediction test. No
score movement follows.
The forty-seventh pass is recorded in `notes/agr-coca-uncertainty-summary-2026-06-09.md` and
`data/agr-coca-projection/uncertainty-summary.csv`. It reports 95% Wilson intervals for plural share
among target agreement rows in the clean discriminator cells. `Majority` is now the strongest
non-`bunch` discriminator: 105:0 exact target rows with a lower Wilson bound of 0.965, and 142:0
when augmented by the omission audit. Animate `bunch` remains strong at 71:1 with lower bound 0.925.
`The rest of the people` is directionally clean at 14:0 but wide, with lower bound 0.785. No score
movement follows.
The forty-eighth pass is recorded in `notes/agr-coca-vertical-slice-report-2026-06-09.md`. It
consolidates the AGR COCA lane into a publication-facing worked example: method, discriminator,
measurement audit, uncertainty summary, warranted claim, and limits. The report states the current
publishable pilot claim narrowly: in the checked English production cells, plural agreement is not a
raw-query artifact and is not predicted by a simple surface-head-number baseline, with the strongest
pressure from `majority` plus the denominator omission audit. No graph mutation or score movement
follows.
The forty-ninth pass is recorded in `notes/agr-coca-ablation-test-2026-06-09.md`, supported by
`scripts/run_agr_ablation.py` and `data/agr-coca-projection/ablation-summary.csv`. The ablation
shows that `notional_agreement_basis` and the controller/alignment split are load-bearing across
the COCA and held-out agreement evaluations. `production_probability` and
`retrieval_attractor_salience` are load-bearing for the COCA/projection layer, while
`agreement_override_pattern` is load-bearing for held-out agreement scope. No compression, graph
mutation, or score movement follows.
The fiftieth pass is recorded in `notes/scoped-module-load-bearing-audit-2026-06-09.md`, supported
by `scripts/audit_authorizing_load_bearing.py` and
`data/module-compression/authorizing-load-bearing.csv`. The audit checks whether each scoped
module's distinctive nodes are used by its authorizing evaluation. It protects `FDL`/`UOB` and
`OPG`/`DYN` from immediate merger, while flagging `ART.judgment_task_setting` and `DYN.entrenchment`
as provisional nodes absent from their authorizing evaluations. The audit alone did not justify a
module merger or score movement.
The fifty-first pass is recorded in `notes/provisional-node-trim-2026-06-09.md`. It trims
`judgment_task_setting_t1` from `audience-reference-tracking-candidate` and `entrenchment_t1` from
`context-indexed-dynamic-feedback-candidate` because neither node was used by the module's
authorizing evaluation or scoped label. The regenerated load-bearing audit now has no
`not_authorized` distinctive nodes. No score movement follows.
The fifty-second pass is recorded in
`notes/critic-verdict-variance-agr-coca-2026-06-09.md`, supported by
`data/critic-variance/` and `scripts/summarize_critic_variance.py`. Three independent read-only
Codex critic runs preserved the strongest AGR COCA labels (`bunch` animate, `majority`, and the
majority denominator audit), but two of three critics downgraded the partitive/QN people-frame test
from `passed` to `mixed` because the largest positive cell is sample-coded rather than fully
filtered. The evaluation now records that test as `mixed`. The card-level `survives_as_module`
label remains, and no graph mutation or score movement follows.
The fifty-third pass is recorded in
`notes/agr-coca-lots-full-filter-attempt-2026-06-09.md`. It adds `--all-pages` support to
`scripts/fetch_coca_kwic_from_list.mjs` so COCA KWIC page links can be followed and combined when
the site exposes paginated result pages. A live full-filter attempt for `lots of people are` did not
complete because COCA returned server-error/timeout states. No all-page artifact, evidence-label
upgrade, graph mutation, or score movement follows.
The fifty-fourth pass is recorded in
`notes/agr-coca-partitive-filtered-subset-2026-06-09.md`. It separates the already fully filtered
partitive/QN subset from the broader mixed partitive/QN claim. The new
`partitive-qn-fully-filtered-subset` prediction test is `passed` on 77 filtered plural target rows
and 0 licensed singular target rows, without using the sample-coded `lots of people are` positive
cell. The broad `partitive-qn-coca-targeted-kwic` test remains `mixed`. No graph mutation or score
movement follows.
The fifty-fifth pass is recorded in
`notes/pronoun-audience-projection-scaffold-2026-06-09.md`. It turns the existing
pronoun/audience-policy task design into a data-ready scaffold in
`data/audience-reference-projection/`: stimulus register, response-channel schema, prediction
register, and coding schema. This makes the mixed `audience-policy-framing-prediction` runnable
without changing its evidence status. No graph mutation or score movement follows.
An internal state-of-search report now summarizes the current scoped-module partition, evaluation
ladder, the completed transparent-relative Lane A pass, and remaining empirical lanes without
authorizing score movement.

## Current Candidate Stack

- `licensing-ideology-split-candidate`
- `opportunity-preemption-operator-gap-candidate`
- `stratified-licensing-measurement-candidate`
- `dynamic-stratified-feedback-candidate`
- `context-indexed-dynamic-feedback-candidate`
- `context-aware-operator-gap-candidate`
- `category-measurement-discipline-candidate`
- `context-indexed-task-separated-feedback-candidate`
- `audience-reference-tracking-candidate`
- `selection-collocation-split-candidate`
- `processing-naturalness-perturbation-candidate`
- `uptake-operator-boundary-candidate`
- `frame-specific-dependency-licensing-candidate`
- `repair-neighbour-reconstruction-candidate`
- `information-normalized-repair-candidate`
- `meaning-prior-reconstruction-candidate`
- `agreement-controller-override-candidate`
- `temporal-anchor-alignment-candidate`

The current strongest modules are scoped, not general winners:

- `context-indexed-dynamic-feedback-candidate` for diachronic/context-conditioned licensing,
  production, ideology, correction, and judgment. This graph is now profiled only on activated
  evaluation paths.
- `context-aware-operator-gap-candidate` for operator-gap, opportunity, recoverability, analogy, and
  repair-pressure cases. This graph uses derived evidential constructs for opportunity-normalized
  attestation and preemption strength.
- `category-measurement-discipline-candidate` for category-analysis and measurement-task
  divergence. It is unscored and has no scoped-module label.
- `context-indexed-task-separated-feedback-candidate` for separating unmonitored or elicited
  production settings from correctness-framed judgment settings. It is unscored and has no
  scoped-module label.
- `audience-reference-tracking-candidate` for pronoun/pro-form reference tracking, personhood
  ascription, audience design, and social-indexical judgment channels. It is a scoped module, not a
  general account.
- `selection-collocation-split-candidate` for distinguishing payload preposition choice,
  collocational rigidity, and argument-linking selection. It is unscored and has no scoped-module
  label.
- `processing-naturalness-perturbation-candidate` for processing cost, recoverability, felt
  naturalness, measurement-task effects, reported acceptability, and attribution perturbations. It
  is a scoped module, not a licensing account.
- `uptake-operator-boundary-candidate` for update-role configuration, repertoire closedness, token
  innovability, operator-repertoire membership, stance, genre fit, repair, and attribution. It is a
  scoped module for clause-type/interjection boundaries, not a general operator-gap account.
- `frame-specific-dependency-licensing-candidate` for question-answer frame fit and
  construction-specific dependency licensing. It is a scoped module for frame-conditioned duration
  answers and construction-specific island variation, not a general dependency or operator-gap
  account.
- `repair-neighbour-reconstruction-candidate` for noisy-channel overacceptance cases where distance
  to a plausible intended repair neighbour drives inflated acceptability. It is an unscored
  one-card candidate, not a scoped module yet.
- `information-normalized-repair-candidate` for noisy-channel acceptability cases where raw repair
  distance must be normalized by target sentence length or information mass. It is an unscored
  successor candidate, not a scoped module yet.
- `meaning-prior-reconstruction-candidate` for semantic noisy-channel cases where a plausible
  intended meaning diverges from literal compositional coherence. It is an unscored candidate, not a
  scoped module yet.
- `agreement-controller-override-candidate` for subject-verb and coordination agreement cases where
  controller identification, licensed override, notional basis, and retrieval-attractor salience
  must be separated. It is now a scoped agreement module through held-out measure and fused
  determiner-head tests, with all numeric scores still zero.
- `temporal-anchor-alignment-candidate` for tense/aspect anchoring, modal temporal inference,
  definite or by-now temporal anchors, current relevance, continuative intervals, experiential
  frames, and narrative perspective. It is an unscored built-on candidate, not a scoped module yet.

`context-indexed-dynamic-feedback-candidate`, `context-aware-operator-gap-candidate`, and
`audience-reference-tracking-candidate`, `processing-naturalness-perturbation-candidate`, and
`uptake-operator-boundary-candidate`, `frame-specific-dependency-licensing-candidate`, and
`agreement-controller-override-candidate` currently have protocol-bound or held-out `scope-only`
evaluations and `scoped_module` labels. No graph has earned a non-zero numeric score or a
`general_account` label.

## Live Boundary Rule

Earlier models are allowed to seed, constrain, and challenge the search. They are not the ontology
the search is required to vindicate. A graph earns standing by improving contrast-cell prediction,
construct separation, or held-out projectibility, not by fitting a prior paper.

## Scaffolded Components

- `ontology/nodes.yaml`
- `ontology/edge-types.yaml`
- `ontology/relation-profiles.yaml`
- `ontology/forbidden-conflations.md`
- `phenomena/index.md`
- source-backed CGEL/local-correction card tranche in `phenomena/cards/`
- source-backed Gibson processing/dependency card tranche in `phenomena/cards/`
- local minimal-pair card tranche in `phenomena/cards/`
- measurement-validity card tranche in `phenomena/cards/`
- temporal-anchor alignment candidate and evaluation in `graphs/archive/` and
  `evaluations/protocol-tests/`
- number-construal/realization consolidation evaluation in `evaluations/protocol-tests/`
- `AGR` COCA projection protocol in `notes/agreement-coca-projection-protocol-2026-06-09.md`
- `AGR` COCA data scaffold in `data/agr-coca-projection/`
- `AGR` vertical-slice report and ablation check in
  `notes/agr-coca-vertical-slice-report-2026-06-09.md` and
  `notes/agr-coca-ablation-test-2026-06-09.md`
- `AGR` ablation runner in `scripts/run_agr_ablation.py`
- `AGR` `lots of people are` full-filter attempt note in
  `notes/agr-coca-lots-full-filter-attempt-2026-06-09.md`
- `AGR` partitive/QN fully filtered subset note in
  `notes/agr-coca-partitive-filtered-subset-2026-06-09.md`
- audience/reference projection scaffold in `data/audience-reference-projection/` and
  `notes/pronoun-audience-projection-scaffold-2026-06-09.md`
- scoped-module load-bearing compression audit in
  `notes/scoped-module-load-bearing-audit-2026-06-09.md`
- provisional-node trim note in `notes/provisional-node-trim-2026-06-09.md`
- compression audit data and runner in `data/module-compression/` and
  `scripts/audit_authorizing_load_bearing.py`
- critic-verdict variance protocol and AGR result note in
  `notes/critic-verdict-variance-protocol-2026-06-09.md` and
  `notes/critic-verdict-variance-agr-coca-2026-06-09.md`
- critic-verdict variance data and scripts in `data/critic-variance/`,
  `scripts/build_critic_variance_packet.py`, and `scripts/summarize_critic_variance.py`
- held-out temporal/modal evaluation in `evaluations/protocol-tests/`
- second held-out temporal-orientation evaluation in `evaluations/protocol-tests/`
- `DISCOVERY_RULES.md`
- initial phenomenon cards in `phenomena/cards/`
- graph schema and seed graphs in `graphs/`
- graph-agent template and scoring rubric in `agents/`
- stdlib validation, linting, and scoring scripts in `scripts/`
- evaluation summary utility in `scripts/summarize_evaluations.py`
- source map and pressure test in `notes/`
- CGEL/Gibson/measurement/local correction source registry in `notes/cgel-source-registry.md`
- conditioning protocol in `notes/conditioning-operationalization-protocol-2026-06-07.md`
- scoped scoring policy in `notes/scoped-scoring-policy-2026-06-07.md`
- task-separated feedback synthesis in `notes/seventh-adversarial-pass-synthesis-2026-06-08.md`
- audience/reference-tracking synthesis in `notes/eighth-adversarial-pass-synthesis-2026-06-08.md`
- selection/collocation synthesis in `notes/ninth-adversarial-pass-synthesis-2026-06-08.md`
- processing/naturalness synthesis in `notes/tenth-adversarial-pass-synthesis-2026-06-08.md`
- uptake/operator boundary synthesis in `notes/eleventh-adversarial-pass-synthesis-2026-06-08.md`
- frequent-condemned-form synthesis in `notes/twelfth-adversarial-pass-synthesis-2026-06-08.md`
- fused-head NP synthesis in `notes/thirteenth-adversarial-pass-synthesis-2026-06-08.md`
- prediction-test synthesis in `notes/fourteenth-adversarial-pass-synthesis-2026-06-08.md`
- source-backed prediction evidence synthesis in
  `notes/fifteenth-adversarial-pass-synthesis-2026-06-08.md`
- unresolved evidence-lane update in `notes/sixteenth-adversarial-pass-synthesis-2026-06-08.md`
- Gibson card-pass synthesis in `notes/seventeenth-adversarial-pass-synthesis-2026-06-09.md`
- Gibson/local-card evaluation synthesis in `notes/eighteenth-adversarial-pass-synthesis-2026-06-09.md`
- frame-specific dependency synthesis in
  `notes/nineteenth-adversarial-pass-synthesis-2026-06-09.md`
- legalese/processing synthesis in
  `notes/twentieth-adversarial-pass-synthesis-2026-06-09.md`
- repair-neighbour reconstruction synthesis in
  `notes/twenty-first-adversarial-pass-synthesis-2026-06-09.md`
- noisy-channel subtype synthesis in
  `notes/twenty-second-adversarial-pass-synthesis-2026-06-09.md`
- information-normalized repair synthesis in
  `notes/twenty-third-adversarial-pass-synthesis-2026-06-09.md`
- INR boundary-test synthesis in
  `notes/twenty-fourth-adversarial-pass-synthesis-2026-06-09.md`
- meaning-prior reconstruction synthesis in
  `notes/twenty-fifth-adversarial-pass-synthesis-2026-06-09.md`
- local operator-contrast synthesis in
  `notes/twenty-sixth-adversarial-pass-synthesis-2026-06-09.md`
- cohort-conditioned complement-selection synthesis in
  `notes/twenty-seventh-adversarial-pass-synthesis-2026-06-09.md`
- CGEL discriminator-pack synthesis in
  `notes/twenty-eighth-adversarial-pass-synthesis-2026-06-09.md`
- agreement-controller mutation synthesis in
  `notes/twenty-ninth-adversarial-pass-synthesis-2026-06-09.md`
- held-out measure-agreement synthesis in
  `notes/thirtieth-adversarial-pass-synthesis-2026-06-09.md`
- held-out fused determiner-head agreement synthesis in
  `notes/thirty-first-adversarial-pass-synthesis-2026-06-09.md`
- unresolved data-pointer synthesis in
  `notes/thirty-second-adversarial-pass-synthesis-2026-06-09.md`
- transparent-relative opportunity measurement design in
  `notes/transparent-relative-opportunity-measurement-design-2026-06-09.md`
- transparent-relative measurement-design synthesis in
  `notes/thirty-third-adversarial-pass-synthesis-2026-06-09.md`
- ANN/fMRI measurement-validity synthesis in
  `notes/thirty-fourth-adversarial-pass-synthesis-2026-06-09.md`
- transparent-relative opportunity data pass in
  `notes/transparent-relative-opportunity-data-pass-2026-06-09.md`
- pronoun audience-policy task design in
  `notes/pronoun-audience-policy-task-design-2026-06-09.md`
- pronoun audience-policy design synthesis in
  `notes/thirty-sixth-adversarial-pass-synthesis-2026-06-09.md`
- independent-relative-`whose` opportunity lane in
  `notes/independent-relative-whose-opportunity-lane-2026-06-09.md`
- independent-relative-`whose` lane synthesis in
  `notes/thirty-seventh-adversarial-pass-synthesis-2026-06-09.md`
- comparative-illusion/category evaluation in
  `evaluations/protocol-tests/category-measurement-discipline-comparative-illusion-2026-06-09.json`
- comparative-illusion/category synthesis in
  `notes/thirty-eighth-adversarial-pass-synthesis-2026-06-09.md`
- state-of-search report with module/evaluation visual maps in
  `notes/state-of-search-report-2026-06-09.md`
- static state visualization in
  `visualizations/workbench-state-2026-06-09.html`
- coverage/discriminator matrix in `notes/coverage-discriminator-matrix-2026-06-08.md`
- protocol-bound evaluation schema and exploratory evaluations in `evaluations/`
- held-out CGEL/local-correction evaluations in `evaluations/protocol-tests/`
- agreement, center-embedding, uptake-boundary, frequent-condemned-form, fused-head,
  Gibson-backed, local minimal-pair, local operator-contrast, frame-specific dependency, and
  measurement-validity evaluations in
  `evaluations/protocol-tests/`
- positive and negative validator fixtures in `tests/fixtures/`

## Current Tooling Gates

Run these over seeds plus archive candidates:

```bash
python3 scripts/validate_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/lint_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/score_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/validate_evaluation.py evaluations/protocol-tests/*.json
python3 scripts/run_fixture_tests.py
```

For a compact view of evaluation state:

```bash
python3 scripts/summarize_evaluations.py evaluations/protocol-tests/*.json
```

The linter now checks:

- controlled node IDs, including time-sliced extensions;
- relation profiles against the controlled registry and edge-type compatibility;
- profiled graphs have at least one profiled edge;
- graph IDs against filename stems;
- family/status conventions;
- complete score blocks where present;
- score values in the 0-5 range;
- discovery-specific score dimensions for held-out projectibility and theory-preservation penalty;
- all-zero seed score discipline;
- `score_status` metadata for non-zero scores;
- required evaluation references for scoped/general labels;
- evaluation references whose `target_graph` matches the labelled graph;
- scoped/general labels only when the referenced evaluation authorizes scope recognition;
- `general_account` labels only when the referenced evaluation is held-out and proposes score
  movement;
- non-zero scores only when the referenced evaluation authorizes score movement;
- held-out evaluation references resolve `held_out_from` items to cards or evaluations;
- non-zero scores only on graphs with `edge_semantics_level: profiled`;
- `conditioning_axes` metadata for context-indexed graph families;
- declared conditioning axes against corresponding graph nodes;
- conditioning-axis nodes that are outcome-like or have directed paths to outcome-like nodes.

The graph validator checks:

- allowed edge types;
- edge endpoint membership;
- duplicate typed edges;
- acyclicity of non-`time_lagged` edges;
- forward direction for `time_lagged` edges;
- no backward cross-time edges and no forward cross-time effects except `time_lagged`.

The evaluation validator checks:

- protocol-bound evaluations against target graph paths, protocol paths, phenomenon card IDs,
  allowed result labels, and complete six-axis contrast cells.
- card-level requirements for required/forbidden target-graph nodes and edges.
- held-out evaluations include non-empty `held_out_from` provenance resolved to cards or
  evaluations.
- activated paths, when present, resolve to target-graph edges and continue as directed paths.
- `score-change-proposed` evaluations target graphs whose `edge_semantics_level` is `profiled`.
- `score-change-proposed` evaluations include activated paths whose edges have relation profiles.
- activated paths with `expected_path_reading` match the path reading computed from relation
  profiles; score-change paths require an expected reading.
- prediction tests, when present, resolve to a phenomenon card, contrast cell, and activated path
  or paths from the same evaluation.
- `score-change-proposed` evaluations include prediction tests with explicit pass/fail conditions.

The fixture runner checks positive and negative cases for both graph linting and evaluation
validation.

## Next Actions

1. Retry the `lots of people are` all-page KWIC fetch after the COCA session/rate state clears only
   if the broad partitive/QN test needs to move beyond `mixed`; the smaller fully filtered subset is
   already recorded as a separate `passed` test.
2. Run a small pilot or structured critic pass over
   `data/audience-reference-projection/stimulus-register.csv` if data collection is available.
3. Mutate `TEMP` with a temporal-orientation frame if continuing the temporal lane; keep it distinct
   from modal temporal inference and from English future-tense analysis.
4. Add one more catenative card only if it distinguishes catenative subtype from cohort-conditioned
   production.
5. Test comparative-illusion cards against combined `CAT` plus noisy-channel interpretations only
   if a future card forces an interaction rather than complementarity.
6. Test whether `OPG`, `CAT`, and `SEL` stay complementary on richer fused-construction cards before
   adding any fused-head-specific graph.
7. Calibrate scoped-module score magnitudes after at least one held-out or parameterized evaluation
   pass.
8. Expand `phenomena/cards/` toward 40-100 cards only after the current representation classes stop
   shifting every pass.
9. Only after the construct inventory stabilizes, consider whether `pgmpy`, NOTEARS-style methods,
   or empirical causal discovery are useful.
