# Evolutionary DAG Workbench - Status

**Parent:** `Grammaticality_de_idealized`
**Created:** 2026-06-07
**Stage:** Active adversarial iteration
**Public state:** Private working subproject; no public claims or submission state.

## Current State

The subproject is now active as a discovery-first workbench for exploring rival conceptual
representations about grammaticality. The existing OVMG, detector, operator-stratum, usage-based,
processing-based, and normativity-based models are treated as seed graph families, not as
conclusions or targets to vindicate.

Five adversarial passes and one synthesis pass have been run. All numeric scores remain zero. Two
current modules have `scoped_module` labels tied to protocol-bound evaluations. No graph has a
`general_account` score. The current scoring schema now includes `projective_power` and
`theory_preservation_penalty` so held-out prediction and anti-alignment discipline are visible.

## Current Candidate Stack

- `licensing-ideology-split-candidate`
- `opportunity-preemption-operator-gap-candidate`
- `stratified-licensing-measurement-candidate`
- `dynamic-stratified-feedback-candidate`
- `context-indexed-dynamic-feedback-candidate`
- `context-aware-operator-gap-candidate`

The current strongest modules are scoped, not general winners:

- `context-indexed-dynamic-feedback-candidate` for diachronic/context-conditioned licensing,
  production, ideology, correction, and judgment.
- `context-aware-operator-gap-candidate` for operator-gap, opportunity, recoverability, analogy, and
  repair-pressure cases. This is the first profiled graph and uses derived evidential constructs for
  opportunity-normalized attestation and preemption strength.

Both have protocol-bound `scope-only` evaluations and `scoped_module` labels. Neither has earned a
non-zero numeric score or a `general_account` score.

## Live Boundary Rule

Earlier models are allowed to seed, constrain, and challenge the search. They are not the ontology
the search is required to vindicate. A graph earns standing by improving contrast-cell prediction,
construct separation, or held-out projectibility, not by fitting a prior paper.

## Scaffolded Components

- `ontology/nodes.yaml`
- `ontology/edge-types.yaml`
- `ontology/relation-profiles.yaml`
- `ontology/forbidden-conflations.md`
- `phenomena/index.md`
- `DISCOVERY_RULES.md`
- initial phenomenon cards in `phenomena/cards/`
- graph schema and seed graphs in `graphs/`
- graph-agent template and scoring rubric in `agents/`
- stdlib validation, linting, and scoring scripts in `scripts/`
- source map and pressure test in `notes/`
- conditioning protocol in `notes/conditioning-operationalization-protocol-2026-06-07.md`
- scoped scoring policy in `notes/scoped-scoring-policy-2026-06-07.md`
- protocol-bound evaluation schema and exploratory evaluations in `evaluations/`
- positive and negative validator fixtures in `tests/fixtures/`

## Current Tooling Gates

Run these over seeds plus archive candidates:

```bash
python3 scripts/validate_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/lint_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/score_graph.py graphs/seeds/*.json graphs/archive/*.json
python3 scripts/validate_evaluation.py evaluations/protocol-tests/*.json
python3 scripts/run_fixture_tests.py
```

The linter now checks:

- controlled node IDs, including time-sliced extensions;
- relation profiles against the controlled registry and edge-type compatibility;
- profiled graphs have at least one profiled edge;
- graph IDs against filename stems;
- family/status conventions;
- complete score blocks where present;
- score values in the 0-5 range;
- discovery-specific score dimensions for held-out projectibility and theory-preservation penalty;
- all-zero seed score discipline;
- `score_status` metadata for non-zero scores;
- required evaluation references for scoped/general labels;
- evaluation references whose `target_graph` matches the labelled graph;
- scoped/general labels only when the referenced evaluation authorizes scope recognition;
- non-zero scores only when the referenced evaluation authorizes score movement;
- held-out evaluation references declare what cards, evaluations, or passes they were held out from;
- non-zero scores only on graphs with `edge_semantics_level: profiled`;
- `conditioning_axes` metadata for context-indexed graph families;
- declared conditioning axes against corresponding graph nodes;
- conditioning-axis nodes that are outcome-like or have directed paths to outcome-like nodes.

The graph validator checks:

- allowed edge types;
- edge endpoint membership;
- duplicate typed edges;
- acyclicity of non-`time_lagged` edges;
- forward direction for `time_lagged` edges;
- no backward cross-time edges and no forward cross-time effects except `time_lagged`.

The evaluation validator checks:

- protocol-bound evaluations against target graph paths, protocol paths, phenomenon card IDs,
  allowed result labels, and complete six-axis contrast cells.
- held-out evaluations include non-empty `held_out_from` provenance.

The fixture runner checks positive and negative cases for both graph linting and evaluation
validation.

## Next Actions

1. Enrich the current twelve phenomenon cards before adding more cards.
2. Add held-out protocol evaluations before any numeric score movement.
3. Start the next graph mutation from a card failure or held-out discriminator, not from a named
   theory family.
4. Add a processing-specific context module or keep processing as a perturbation layer only.
5. Profile `context-indexed-dynamic-feedback-candidate` only after deciding which dynamic paths are
   prediction commitments.
6. Add evaluation-level activated paths so score movement can require profiles on the traversed
   prediction paths, not merely a profiled graph.
7. Calibrate scoped-module score magnitudes after at least one held-out or parameterized evaluation
   pass.
8. Expand `phenomena/cards/` toward 40-100 cards only after the current representation classes stop
   shifting every pass.
9. Only after the construct inventory stabilizes, consider whether `pgmpy`, NOTEARS-style methods,
   or empirical causal discovery are useful.
